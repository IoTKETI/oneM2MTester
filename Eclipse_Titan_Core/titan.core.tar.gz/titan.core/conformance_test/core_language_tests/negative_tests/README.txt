// README to negative conformance tests

How to run:
The tests can be started all at once:
	./run_test_all

How to run scripts individually:
	./SAtester.pl scriptname.script
