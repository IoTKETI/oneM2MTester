/*****************************************************************
 ** @author   STF 470
 ** @version  0.0.1
 ** @purpose  1:8.2.3.1, Verify that identifiers of parameter types are not imported together with external functions
 ** @verdict  pass reject
 *****************************************************************/

#include "NegSem_08020301_GeneralFormatOfImport_031_import.hh"

namespace NegSem__08020301__GeneralFormatOfImport__031__import
{
	void f__test(const MyType &p)
    {}
}
