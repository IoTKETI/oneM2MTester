/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_CONFIG_PROCESS_CONFIG_PROCESS_TAB_HH_INCLUDED
# define YY_CONFIG_PROCESS_CONFIG_PROCESS_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int config_process_debug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    ModuleParametersKeyword = 258,
    LoggingKeyword = 259,
    ProfilerKeyword = 260,
    TestportParametersKeyword = 261,
    ExecuteKeyword = 262,
    ExternalCommandsKeyword = 263,
    GroupsKeyword = 264,
    ComponentsKeyword = 265,
    MainControllerKeyword = 266,
    IncludeKeyword = 267,
    DefineKeyword = 268,
    Detailed = 269,
    Compact = 270,
    ObjIdKeyword = 271,
    CharKeyword = 272,
    ControlKeyword = 273,
    MTCKeyword = 274,
    SystemKeyword = 275,
    NULLKeyword = 276,
    nullKeyword = 277,
    OmitKeyword = 278,
    ComplementKeyword = 279,
    DotDot = 280,
    SupersetKeyword = 281,
    SubsetKeyword = 282,
    PatternKeyword = 283,
    PermutationKeyword = 284,
    LengthKeyword = 285,
    IfpresentKeyword = 286,
    InfinityKeyword = 287,
    NocaseKeyword = 288,
    AssignmentChar = 289,
    ConcatChar = 290,
    LogFile = 291,
    EmergencyLogging = 292,
    EmergencyLoggingBehaviour = 293,
    EmergencyLoggingMask = 294,
    EmergencyLoggingForFailVerdict = 295,
    BufferAll = 296,
    BufferMasked = 297,
    FileMask = 298,
    ConsoleMask = 299,
    TimestampFormat = 300,
    ConsoleTimestampFormat = 301,
    SourceInfoFormat = 302,
    AppendFile = 303,
    LogEventTypes = 304,
    LogEntityName = 305,
    BeginControlPart = 306,
    EndControlPart = 307,
    BeginTestCase = 308,
    EndTestCase = 309,
    Identifier = 310,
    ASN1LowerIdentifier = 311,
    Number = 312,
    MPNumber = 313,
    Float = 314,
    MPFloat = 315,
    BooleanValue = 316,
    VerdictValue = 317,
    Bstring = 318,
    Hstring = 319,
    Ostring = 320,
    BstringMatch = 321,
    HstringMatch = 322,
    OstringMatch = 323,
    Cstring = 324,
    MPCstring = 325,
    UIDval = 326,
    DNSName = 327,
    LoggingBit = 328,
    LoggingBitCollection = 329,
    SubCategories = 330,
    EmergencyLoggingBehaviourValue = 331,
    TimestampValue = 332,
    SourceInfoValue = 333,
    YesNo = 334,
    LocalAddress = 335,
    TCPPort = 336,
    KillTimer = 337,
    NumHCs = 338,
    UnixSocketEnabled = 339,
    YesToken = 340,
    NoToken = 341,
    LogFileSize = 342,
    LogFileNumber = 343,
    DiskFullAction = 344,
    MatchingHints = 345,
    LoggerPlugins = 346,
    Error = 347,
    Stop = 348,
    Retry = 349,
    Delete = 350,
    TtcnStringParsingKeyword = 351,
    DisableProfilerKeyword = 352,
    DisableCoverageKeyword = 353,
    DatabaseFileKeyword = 354,
    AggregateDataKeyword = 355,
    StatisticsFileKeyword = 356,
    DisableStatisticsKeyword = 357,
    StatisticsFilterKeyword = 358,
    StartAutomaticallyKeyword = 359,
    NetLineTimesKeyword = 360,
    NetFunctionTimesKeyword = 361,
    ProfilerStatsFlag = 362,
    UnarySign = 363
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 121 "config_process.y" /* yacc.c:1909  */

	char 					*str_val;
	int_val_t				*int_val;
	int						int_native;
	unsigned int			uint_val;
	double					float_val;
	boolean					bool_val;
	param_objid_t			objid_val;
	verdicttype				verdict_val;
	param_bitstring_t		bitstring_val;
	param_hexstring_t		hexstring_val;
	param_charstring_t		charstring_val;
	param_octetstring_t		octetstring_val;
	universal_char			universal_char_val;
	param_universal_charstring_t universal_charstring_val;
	Module_Param::operation_type_t param_optype_val;
  Vector<Module_Param*>* module_param_list;
	Module_Param*			module_param_val;
  Module_Param_Length_Restriction* module_param_length_restriction;
	Vector<char*>*		name_vector;
	component_id_t		comp_id;
	execute_list_item	execute_item_val;
	TTCN_Logger::emergency_logging_behaviour_t emergency_logging_behaviour_value;
	TTCN_Logger::timestamp_format_t timestamp_value;
	TTCN_Logger::source_info_format_t source_info_value;
  TTCN_Logger::log_event_types_t log_event_types_value;
  TTCN_Logger::disk_full_action_t disk_full_action_value;
  TTCN_Logger::matching_verbosity_t matching_verbosity_value;
	TTCN_Logger::Severity	logseverity_val;
	Logging_Bits logoptions_val;

  logging_plugin_t *logging_plugins;
	logging_param_t logging_params;
	logging_setting_t logging_param_line;
  struct {
    size_t nElements;
    char **elements;
  } uid_list;

#line 203 "config_process.tab.hh" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE config_process_lval;

int config_process_parse (void);

#endif /* !YY_CONFIG_PROCESS_CONFIG_PROCESS_TAB_HH_INCLUDED  */
