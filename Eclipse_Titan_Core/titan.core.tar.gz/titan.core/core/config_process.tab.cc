/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1


/* Substitute the variable and function names.  */
#define yyparse         config_process_parse
#define yylex           config_process_lex
#define yyerror         config_process_error
#define yydebug         config_process_debug
#define yynerrs         config_process_nerrs

#define yylval          config_process_lval
#define yychar          config_process_char

/* Copy the first part of user declarations.  */
#line 26 "config_process.y" /* yacc.c:339  */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <errno.h>

#include <openssl/bn.h>

#include "../common/config_preproc.h"

#include "Param_Types.hh"
#include "Integer.hh"
#include "Float.hh"
#include "Boolean.hh"
#include "Objid.hh"
#include "Verdicttype.hh"
#include "Bitstring.hh"
#include "Hexstring.hh"
#include "Octetstring.hh"
#include "Charstring.hh"
#include "Universal_charstring.hh"

#include "Module_list.hh"
#include "Port.hh"
#include "Runtime.hh"

#include "LoggingBits.hh"
#include "LoggingParam.hh"

#include "Profiler.hh"
#include "Debugger.hh"
#include "DebugCommands.hh"

#define YYERROR_VERBOSE

#include "config_process.lex.hh"

#ifndef INFINITY
#include <float.h>
static const double INFINITY = (DBL_MAX*DBL_MAX);
#endif


extern void reset_config_process_lex(const char* fname);
extern void config_process_close();
extern int config_process_get_current_line();
extern std::string get_cfg_process_current_file();

static int config_process_parse();
static void check_duplicate_option(const char *section_name,
    const char *option_name, boolean& option_flag);
static void check_ignored_section(const char *section_name);
static void set_param(Module_Param& module_param);
static unsigned char char_to_hexdigit_(char c);

static boolean error_flag = FALSE;

static Module_Param* parsed_module_param = NULL;
static char * parsing_error_messages = NULL;

/*
For detecting duplicate entries in the config file. Start out as FALSE,
set to TRUE bycheck_duplicate_option().
Exception: duplication of parameters that can be component specific is checked
by set_xxx(), these start out as TRUE.
*/
static boolean file_name_set = FALSE,
	file_mask_set = TRUE,
	console_mask_set = TRUE,
	timestamp_format_set = FALSE,
	source_info_format_set = FALSE,
	append_file_set = FALSE,
	log_event_types_set = FALSE,
	log_entity_name_set = FALSE,
	begin_controlpart_command_set = FALSE,
	end_controlpart_command_set = FALSE,
	begin_testcase_command_set = FALSE,
	end_testcase_command_set = FALSE,
	log_file_size_set = TRUE,
	log_file_number_set = TRUE,
	log_disk_full_action_set = TRUE,
	matching_verbosity_set = FALSE,
	logger_plugins_set = FALSE,
	plugin_specific_set = FALSE;

int execute_list_len = 0;
execute_list_item *execute_list = NULL;

string_map_t *config_defines;


#line 169 "config_process.tab.cc" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "config_process.tab.hh".  */
#ifndef YY_CONFIG_PROCESS_CONFIG_PROCESS_TAB_HH_INCLUDED
# define YY_CONFIG_PROCESS_CONFIG_PROCESS_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int config_process_debug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    ModuleParametersKeyword = 258,
    LoggingKeyword = 259,
    ProfilerKeyword = 260,
    TestportParametersKeyword = 261,
    ExecuteKeyword = 262,
    ExternalCommandsKeyword = 263,
    GroupsKeyword = 264,
    ComponentsKeyword = 265,
    MainControllerKeyword = 266,
    IncludeKeyword = 267,
    DefineKeyword = 268,
    Detailed = 269,
    Compact = 270,
    ObjIdKeyword = 271,
    CharKeyword = 272,
    ControlKeyword = 273,
    MTCKeyword = 274,
    SystemKeyword = 275,
    NULLKeyword = 276,
    nullKeyword = 277,
    OmitKeyword = 278,
    ComplementKeyword = 279,
    DotDot = 280,
    SupersetKeyword = 281,
    SubsetKeyword = 282,
    PatternKeyword = 283,
    PermutationKeyword = 284,
    LengthKeyword = 285,
    IfpresentKeyword = 286,
    InfinityKeyword = 287,
    NocaseKeyword = 288,
    AssignmentChar = 289,
    ConcatChar = 290,
    LogFile = 291,
    EmergencyLogging = 292,
    EmergencyLoggingBehaviour = 293,
    EmergencyLoggingMask = 294,
    EmergencyLoggingForFailVerdict = 295,
    BufferAll = 296,
    BufferMasked = 297,
    FileMask = 298,
    ConsoleMask = 299,
    TimestampFormat = 300,
    ConsoleTimestampFormat = 301,
    SourceInfoFormat = 302,
    AppendFile = 303,
    LogEventTypes = 304,
    LogEntityName = 305,
    BeginControlPart = 306,
    EndControlPart = 307,
    BeginTestCase = 308,
    EndTestCase = 309,
    Identifier = 310,
    ASN1LowerIdentifier = 311,
    Number = 312,
    MPNumber = 313,
    Float = 314,
    MPFloat = 315,
    BooleanValue = 316,
    VerdictValue = 317,
    Bstring = 318,
    Hstring = 319,
    Ostring = 320,
    BstringMatch = 321,
    HstringMatch = 322,
    OstringMatch = 323,
    Cstring = 324,
    MPCstring = 325,
    UIDval = 326,
    DNSName = 327,
    LoggingBit = 328,
    LoggingBitCollection = 329,
    SubCategories = 330,
    EmergencyLoggingBehaviourValue = 331,
    TimestampValue = 332,
    SourceInfoValue = 333,
    YesNo = 334,
    LocalAddress = 335,
    TCPPort = 336,
    KillTimer = 337,
    NumHCs = 338,
    UnixSocketEnabled = 339,
    YesToken = 340,
    NoToken = 341,
    LogFileSize = 342,
    LogFileNumber = 343,
    DiskFullAction = 344,
    MatchingHints = 345,
    LoggerPlugins = 346,
    Error = 347,
    Stop = 348,
    Retry = 349,
    Delete = 350,
    TtcnStringParsingKeyword = 351,
    DisableProfilerKeyword = 352,
    DisableCoverageKeyword = 353,
    DatabaseFileKeyword = 354,
    AggregateDataKeyword = 355,
    StatisticsFileKeyword = 356,
    DisableStatisticsKeyword = 357,
    StatisticsFilterKeyword = 358,
    StartAutomaticallyKeyword = 359,
    NetLineTimesKeyword = 360,
    NetFunctionTimesKeyword = 361,
    ProfilerStatsFlag = 362,
    UnarySign = 363
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 121 "config_process.y" /* yacc.c:355  */

	char 					*str_val;
	int_val_t				*int_val;
	int						int_native;
	unsigned int			uint_val;
	double					float_val;
	boolean					bool_val;
	param_objid_t			objid_val;
	verdicttype				verdict_val;
	param_bitstring_t		bitstring_val;
	param_hexstring_t		hexstring_val;
	param_charstring_t		charstring_val;
	param_octetstring_t		octetstring_val;
	universal_char			universal_char_val;
	param_universal_charstring_t universal_charstring_val;
	Module_Param::operation_type_t param_optype_val;
  Vector<Module_Param*>* module_param_list;
	Module_Param*			module_param_val;
  Module_Param_Length_Restriction* module_param_length_restriction;
	Vector<char*>*		name_vector;
	component_id_t		comp_id;
	execute_list_item	execute_item_val;
	TTCN_Logger::emergency_logging_behaviour_t emergency_logging_behaviour_value;
	TTCN_Logger::timestamp_format_t timestamp_value;
	TTCN_Logger::source_info_format_t source_info_value;
  TTCN_Logger::log_event_types_t log_event_types_value;
  TTCN_Logger::disk_full_action_t disk_full_action_value;
  TTCN_Logger::matching_verbosity_t matching_verbosity_value;
	TTCN_Logger::Severity	logseverity_val;
	Logging_Bits logoptions_val;

  logging_plugin_t *logging_plugins;
	logging_param_t logging_params;
	logging_setting_t logging_param_line;
  struct {
    size_t nElements;
    char **elements;
  } uid_list;

#line 358 "config_process.tab.cc" /* yacc.c:355  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE config_process_lval;

int config_process_parse (void);

#endif /* !YY_CONFIG_PROCESS_CONFIG_PROCESS_TAB_HH_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 373 "config_process.tab.cc" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  50
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   819

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  126
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  112
/* YYNRULES -- Number of rules.  */
#define YYNRULES  308
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  573

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   363

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   118,     2,     2,     2,     2,   108,     2,
     115,   116,   111,   109,   121,   110,   114,   112,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,   125,
       2,     2,     2,   117,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   122,     2,   123,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   119,   124,   120,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   113
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   410,   410,   416,   422,   424,   428,   429,   430,   431,
     432,   433,   434,   435,   436,   437,   438,   442,   445,   447,
     451,   463,   464,   468,   473,   478,   486,   490,   495,   500,
     509,   514,   523,   531,   552,   553,   554,   555,   556,   557,
     561,   565,   569,   573,   582,   600,   604,   608,   612,   616,
     620,   624,   628,   632,   636,   640,   644,   648,   652,   656,
     660,   664,   668,   672,   676,   680,   684,   688,   692,   719,
     731,   755,   762,   767,   774,   778,   782,   786,   790,   794,
     798,   802,   809,   813,   817,   821,   825,   829,   833,   837,
     841,   845,   849,   853,   860,   880,   900,   920,   944,   945,
     946,   947,   954,   963,   972,   981,  1001,  1002,  1003,  1004,
    1005,  1006,  1007,  1008,  1018,  1022,  1029,  1040,  1041,  1045,
    1049,  1057,  1061,  1065,  1069,  1075,  1103,  1116,  1125,  1181,
    1188,  1195,  1205,  1210,  1218,  1222,  1226,  1230,  1234,  1242,
    1248,  1254,  1263,  1267,  1274,  1279,  1287,  1292,  1300,  1308,
    1312,  1319,  1325,  1334,  1338,  1347,  1352,  1360,  1368,  1387,
    1390,  1392,  1445,  1452,  1458,  1464,  1482,  1500,  1504,  1512,
    1519,  1529,  1530,  1534,  1539,  1544,  1550,  1556,  1561,  1566,
    1571,  1577,  1582,  1587,  1592,  1596,  1601,  1606,  1611,  1616,
    1621,  1630,  1631,  1635,  1636,  1637,  1642,  1648,  1652,  1656,
    1661,  1778,  1782,  1790,  1791,  1798,  1799,  1803,  1805,  1806,
    1812,  1815,  1817,  1821,  1822,  1823,  1824,  1825,  1826,  1827,
    1828,  1829,  1830,  1834,  1840,  1846,  1852,  1858,  1864,  1870,
    1874,  1880,  1881,  1882,  1886,  1897,  1903,  1912,  1915,  1917,
    1921,  1933,  1938,  1943,  1949,  1954,  1959,  1967,  1968,  1973,
    1977,  1987,  1999,  2003,  2009,  2017,  2019,  2034,  2039,  2044,
    2049,  2059,  2062,  2064,  2068,  2077,  2086,  2095,  2107,  2113,
    2119,  2121,  2125,  2129,  2133,  2134,  2138,  2139,  2143,  2144,
    2149,  2155,  2157,  2161,  2165,  2166,  2170,  2171,  2176,  2182,
    2184,  2188,  2189,  2190,  2191,  2192,  2193,  2194,  2198,  2199,
    2204,  2213,  2215,  2219,  2224,  2236,  2241,  2247,  2249
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ModuleParametersKeyword",
  "LoggingKeyword", "ProfilerKeyword", "TestportParametersKeyword",
  "ExecuteKeyword", "ExternalCommandsKeyword", "GroupsKeyword",
  "ComponentsKeyword", "MainControllerKeyword", "IncludeKeyword",
  "DefineKeyword", "Detailed", "Compact", "\"objid\"", "\"char\"",
  "\"control\"", "\"mtc\"", "\"system\"", "\"NULL\"", "\"null\"",
  "\"omit\"", "\"complement\"", "\"..\"", "\"superset\"", "\"subset\"",
  "\"pattern\"", "\"permutation\"", "\"length\"", "\"ifpresent\"",
  "\"infinity\"", "\"@nocase\"", "\":= or =\"", "\"&=\"",
  "\"LogFile or FileName\"", "EmergencyLogging",
  "EmergencyLoggingBehaviour", "EmergencyLoggingMask",
  "EmergencyLoggingForFailVerdict", "BufferAll", "BufferMasked",
  "FileMask", "ConsoleMask", "TimestampFormat", "ConsoleTimestampFormat",
  "\"LogSourceInfo or SourceInfoFormat\"", "AppendFile", "LogEventTypes",
  "LogEntityName", "BeginControlPart", "EndControlPart", "BeginTestCase",
  "EndTestCase", "Identifier",
  "\"ASN.1 identifier beginning with a lowercase letter\"", "Number",
  "\"integer value\"", "Float", "\"float value\"", "\"true or false\"",
  "VerdictValue", "\"bit string value\"", "\"hex string value\"",
  "\"octet string value\"", "\"bit string template\"",
  "\"hex string template\"", "\"octet string template\"", "Cstring",
  "\"charstring value\"", "UIDval", "\"hostname\"", "LoggingBit",
  "LoggingBitCollection", "SubCategories", "\"BufferAll or BufferMasked\"",
  "\"Time, Datetime or Seconds\"", "\"None, Single or Stack\"",
  "\"yes or no\"", "LocalAddress", "TCPPort", "KillTimer", "NumHCs",
  "UnixSocketEnabled", "\"yes\"", "\"no\"", "LogFileSize", "LogFileNumber",
  "DiskFullAction", "MatchingHints", "LoggerPlugins", "Error", "Stop",
  "Retry", "Delete", "TtcnStringParsingKeyword", "\"DisableProfiler\"",
  "\"DisableCoverage\"", "\"DatabaseFile\"", "\"AggregateData\"",
  "\"StatisticsFile\"", "\"DisableStatistics\"", "\"StatisticsFilter\"",
  "\"StartAutomatically\"", "\"NetLineTimes\"", "\"NetFunctionTimes\"",
  "\"profiler statistics filter\"", "'&'", "'+'", "'-'", "'*'", "'/'",
  "UnarySign", "'.'", "'('", "')'", "'?'", "'!'", "'{'", "'}'", "','",
  "'['", "']'", "'|'", "';'", "$accept", "GrammarRoot", "ConfigFile",
  "Section", "ModuleParametersSection", "ModuleParameters",
  "ModuleParameter", "ParameterName", "ParameterNameSegment",
  "ParameterValue", "LengthMatch", "LengthBound", "ParameterExpression",
  "ParameterReference", "SimpleParameterValue", "PatternChunk",
  "IntegerRange", "FloatRange", "StringRange", "IntegerValue",
  "FloatValue", "ObjIdValue", "ObjIdComponentList", "ObjIdComponent",
  "NumberForm", "NameAndNumberForm", "BitstringValue", "HexstringValue",
  "OctetstringValue", "UniversalCharstringValue",
  "UniversalCharstringFragment", "Quadruple", "USI", "UIDlike",
  "StringValue", "CompoundValue", "ParameterValueOrNotUsedSymbol",
  "TemplateItemList", "FieldValueList", "FieldValue", "FieldName",
  "ArrayItemList", "ArrayItem", "IndexItemList", "IndexItem",
  "IndexItemIndex", "LoggingSection", "LoggingParamList",
  "LoggingParamLines", "LoggerPluginList", "LoggerPlugin",
  "LoggerPluginId", "LoggingParam", "VerbosityValue",
  "DiskFullActionValue", "LogFileName", "LoggingBitOrCollection",
  "LoggingBitmask", "SourceInfoSetting", "YesNoOrBoolean",
  "LogEventTypesValue", "ProfilerSection", "ProfilerSettings",
  "ProfilerSetting", "DisableProfilerSetting", "DisableCoverageSetting",
  "DatabaseFileSetting", "AggregateDataSetting", "StatisticsFileSetting",
  "DisableStatisticsSetting", "StatisticsFilterSetting",
  "ProfilerStatsFlags", "StartAutomaticallySetting", "NetLineTimesSetting",
  "NetFunctionTimesSetting", "TestportParametersSection",
  "TestportParameterList", "TestportParameter", "ComponentId",
  "TestportName", "ArrayRef", "TestportParameterName",
  "TestportParameterValue", "ExecuteSection", "ExecuteList", "ExecuteItem",
  "ExternalCommandsSection", "ExternalCommandList", "ExternalCommand",
  "Command", "GroupsSection", "GroupList", "Group", "GroupName",
  "GroupMembers", "seqGroupMember", "HostName", "ComponentsSection",
  "ComponentList", "ComponentItem", "ComponentName", "ComponentLocation",
  "MainControllerSection", "MCParameterList", "MCParameter",
  "KillTimerValue", "IncludeSection", "IncludeFiles", "IncludeFile",
  "DefineSection", "ParamOpType", "optSemiColon", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,    38,    43,
      45,    42,    47,   363,    46,    40,    41,    63,    33,   123,
     125,    44,    91,    93,   124,    59
};
# endif

#define YYPACT_NINF -336

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-336)))

#define YYTABLE_NINF -150

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     -69,   451,    75,   769,    15,   -21,  -336,  -336,  -336,  -336,
    -336,    25,    29,    48,   173,  -336,  -336,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,   451,   451,
    -336,   267,  -336,   250,   -59,  -336,    18,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,    47,   371,   451,   451,   451,    57,
      37,  -336,  -336,  -336,  -336,  -336,    96,   161,   179,   516,
      -1,    55,   -13,   206,   224,   147,    78,  -336,   451,  -336,
     451,  -336,  -336,    33,  -336,   234,    87,  -336,   100,  -336,
     241,   230,  -336,   177,  -336,   451,   451,   451,   451,   451,
     273,   -27,   680,   701,    24,   254,   304,   271,   -25,   176,
     284,   221,  -336,    19,  -336,  -336,  -336,  -336,   383,    94,
    -336,    95,    98,   108,   451,  -336,     0,     7,   341,   343,
     346,  -336,   351,   350,  -336,   451,  -336,    -8,   451,   142,
    -336,   184,   579,  -336,   388,  -336,   259,   451,  -336,   451,
     446,   134,   134,  -336,  -336,  -336,   275,   281,   263,   -59,
    -336,  -336,   362,   366,   379,   391,   393,   396,   413,   423,
     425,   426,   432,   450,   453,   455,  -336,  -336,   462,   466,
     467,   468,   474,  -336,   281,  -336,   406,   476,   493,   494,
     497,   500,   507,   289,   511,   512,   513,   281,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,   281,
     415,   435,   281,   525,   530,   531,   533,   281,  -336,   281,
     535,  -336,  -336,   281,   538,   539,   541,   551,   570,   574,
     281,  -336,  -336,   418,  -336,  -336,   451,  -336,   526,  -336,
     451,  -336,  -336,   369,   498,   552,   505,   514,     6,    -7,
       2,    13,   584,    -5,   111,    66,   520,   117,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,    -2,   414,   577,  -336,  -336,
    -336,  -336,   451,   560,   581,   572,   269,     3,   269,   269,
     573,   575,    54,     3,   151,     3,   560,   598,   608,   495,
     349,   534,  -336,   112,   620,   621,   560,   622,   560,   623,
     578,   578,   625,   626,   630,  -336,  -336,   -19,    -3,  -336,
     560,   560,   560,   560,  -336,  -336,   -26,  -336,   133,   141,
      60,   126,    60,    92,  -336,   576,   442,  -336,  -336,  -336,
    -336,   585,  -336,  -336,   586,   587,   588,   592,   261,   593,
     594,   635,   605,   606,    44,   -38,    66,   615,  -336,   616,
    -336,  -336,   596,  -336,   -59,  -336,  -336,   589,  -336,  -336,
    -336,  -336,  -336,  -336,   571,  -336,  -336,  -336,   571,   571,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,   589,  -336,  -336,  -336,  -336,   597,  -336,  -336,  -336,
    -336,  -336,   659,   455,   699,  -336,   624,  -336,  -336,  -336,
     589,  -336,   589,  -336,   -68,  -336,  -336,  -336,  -336,  -336,
     612,  -336,   627,  -336,  -336,  -336,   589,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,   618,  -336,  -336,  -336,  -336,
    -336,  -336,    60,    60,    60,   482,  -336,   126,   126,   126,
     482,   563,  -336,   482,  -336,  -336,  -336,  -336,   451,  -336,
    -336,  -336,  -336,  -336,   632,   642,  -336,  -336,   643,  -336,
    -336,   644,   645,   647,   676,   648,  -336,  -336,   649,   650,
     671,   269,   685,   749,   253,  -336,   665,   707,   578,   578,
      60,   663,   731,   141,  -336,  -336,   191,    60,    60,    60,
      60,  -336,  -336,   312,    -9,    -9,    -9,    -9,   559,  -336,
    -336,  -336,  -336,  -336,  -336,   672,  -336,  -336,  -336,  -336,
    -336,   673,   560,  -336,   659,   659,   455,  -336,  -336,  -336,
     229,    60,  -336,   753,  -336,  -336,   268,   268,  -336,  -336,
    -336,    -9,    -9,    -9,   290,   290,  -336,  -336,   451,  -336,
    -336,   589,  -336,   298,  -336,   239,   560,   353,  -336,  -336,
     589,  -336,  -336
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       4,     0,     0,     2,     0,     0,    59,    60,    57,    58,
      56,     0,     0,     0,     0,    47,    25,    45,    46,    48,
      50,   121,   122,   123,    68,    69,    70,    54,     0,     0,
      62,     0,    61,     0,    44,     3,    26,    35,    34,    63,
      64,    65,    49,    51,    52,    53,    55,   124,   125,    71,
       1,    18,   160,   211,   238,   255,   262,   270,   281,   289,
     301,   304,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,     0,     0,     0,     0,     0,     0,
       0,    72,    66,    73,    37,    38,    45,    46,    54,     0,
       0,     0,    26,     0,   124,     0,    25,   150,   143,   134,
       0,   142,   153,     0,   146,     0,     0,   151,     0,   155,
       0,     0,    24,     0,    28,     0,     0,     0,     0,     0,
      27,    17,   159,   210,   237,   254,   261,   269,   280,   288,
     300,     0,   119,     0,   115,   117,   118,   130,     0,     0,
     144,     0,     0,     0,     0,    67,     0,     0,    47,     0,
       0,   126,     0,     0,   127,     0,    36,     0,     0,     0,
     135,     0,     0,   136,     0,   137,     0,     0,    23,     0,
      43,    39,    40,    41,    42,    29,     0,   307,     0,    21,
     244,   246,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   241,   243,   242,     0,     0,
       0,     0,     0,   245,   307,   162,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   307,   213,   214,
     215,   216,   217,   218,   219,   220,   221,   222,   241,   307,
       0,   257,   307,     0,     0,     0,     0,   307,   273,   307,
       0,   284,   285,   307,     0,     0,     0,     0,     0,     0,
     307,   303,   302,     0,   114,   116,     0,   129,     0,   139,
       0,   140,   141,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   158,   149,
     147,   148,   152,   156,   157,     0,    33,     0,   308,    19,
     305,   306,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   161,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   212,   239,     0,     0,   256,
       0,     0,     0,     0,   263,   271,     0,   282,     0,     0,
       0,     0,     0,     0,   290,     0,     0,   131,   145,    80,
      76,     0,    90,    86,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   138,     0,
      94,   154,     0,    30,    22,    20,   132,   198,   182,   176,
     177,   199,   200,   201,   178,   206,   205,   179,   173,   174,
     183,   184,   203,   185,   204,   186,   209,   208,   207,   187,
     188,   190,   175,   180,   193,   194,   195,   197,   181,   192,
     191,   189,     0,   172,     0,   171,     0,   163,   223,   224,
     225,   226,   227,   228,   231,   229,   230,   234,   235,   236,
     247,   249,     0,   258,   259,   260,   268,   264,   265,   266,
     267,   279,   278,   274,   272,   275,   276,   286,   287,   283,
     291,    98,     0,     0,     0,   292,   106,     0,     0,     0,
     299,   298,   293,   294,   295,   296,   297,   120,     0,    78,
      92,    88,    74,    82,     0,     0,    81,    77,     0,    91,
      87,     0,     0,     0,     0,     0,    95,    96,    47,     0,
       0,     0,     0,   169,     0,   167,     0,     0,     0,     0,
       0,   248,     0,     0,   100,   101,     0,     0,     0,     0,
       0,   108,   109,     0,     0,     0,     0,     0,     0,    75,
      84,    79,    93,    89,    83,     0,    97,    32,    31,   133,
     202,     0,     0,   165,     0,     0,     0,   164,   232,   233,
       0,     0,   252,     0,   277,    99,   102,   103,   104,   105,
     107,     0,     0,     0,   110,   111,   112,   113,     0,    85,
     196,   170,   168,     0,   250,     0,     0,     0,   166,   251,
     253,   240,   128
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -114,     4,
    -336,   420,   -28,  -336,  -336,   710,  -336,  -336,  -336,  -316,
    -335,  -336,  -336,   660,  -336,  -336,  -336,  -336,  -336,  -336,
     -86,   -12,  -336,  -336,  -285,  -336,   646,   -36,  -336,   651,
    -336,  -336,   652,  -336,   653,   -20,  -336,  -336,  -336,   274,
     276,  -336,  -302,  -336,  -336,  -336,   320,   146,  -336,   374,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,  -301,  -336,  -336,  -336,  -336,  -336,  -336,   689,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,    14,
    -336,  -336,  -336,  -336,  -336,  -336,  -329,  -336,  -336,  -336,
    -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,  -336,
    -336,     5
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     2,     3,    62,    63,   121,   177,   178,    34,   140,
     120,   285,    36,    37,    38,    82,    39,    40,    41,   504,
     511,    42,   133,   134,   135,   136,    43,    44,    45,    46,
      93,    47,    48,   139,   436,    49,   102,   141,   103,   104,
     105,   106,   107,   108,   109,   112,    64,   122,   204,   494,
     495,   416,   205,   411,   408,   378,   383,   384,   393,   387,
     399,    65,   123,   217,   218,   219,   220,   221,   222,   223,
     224,   425,   225,   226,   227,    66,   124,   229,   206,   432,
     501,   543,   571,    67,   125,   232,    68,   126,   237,   437,
      69,   127,   239,   240,   444,   445,   446,    70,   128,   243,
     244,   449,    71,   129,   250,   462,    72,   130,   252,    73,
     292,   289
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      84,    85,    83,    92,   153,    35,   461,   179,   377,    79,
     450,   417,    79,   110,   466,   433,    79,   113,   114,    94,
     426,   401,   483,   372,   455,   460,   463,     1,    16,   441,
     241,   420,   263,   422,   359,    91,   430,   101,   354,   266,
     498,   142,   143,   180,   181,   362,   442,   138,   113,   114,
     456,   356,   434,   357,    79,   111,   499,   149,   264,   150,
     360,    85,   151,   100,   385,   151,   355,   267,    83,   151,
      85,   276,   159,   363,   131,    50,   481,   132,   154,   228,
     484,   196,   386,    79,   176,   443,   242,   170,   171,   172,
     173,   174,   431,   197,    75,   115,   116,   117,   118,   119,
     551,   552,   131,   156,   482,   132,   553,    81,   435,   152,
     275,   358,  -149,   366,   373,   385,   138,   451,   265,   274,
     361,   146,   277,   512,   513,   268,   115,   116,   117,   118,
     119,   364,   392,   386,    74,   203,   151,   505,   506,   254,
      76,   286,   505,   506,    77,   154,   110,   441,   182,   183,
     184,   185,   186,   160,   161,   187,   188,   189,   190,   191,
     192,   193,   194,    78,   442,   396,   101,   413,   101,   452,
     453,   284,   144,   374,   544,   454,   155,   464,   465,   554,
     555,   556,   557,   451,   540,   456,   147,   367,   447,   369,
      79,   546,   547,   548,   549,   537,   441,   538,   539,   198,
     199,   200,   201,   414,  -126,   448,    80,   163,   164,   312,
     257,   259,   385,   442,   261,   258,   260,   512,   513,   260,
     165,   166,   325,   415,   262,   565,   397,   368,   346,   260,
     386,   157,   260,   371,   326,   457,   458,   329,   260,   279,
      97,   459,   334,    81,   335,   118,   119,   561,   337,  -127,
     115,   116,   117,   118,   119,   344,   245,   246,   247,   248,
     249,   154,   158,   154,   348,   278,     4,     5,   162,     6,
       7,     8,     9,    10,    11,   167,    12,    13,    14,    95,
     485,   570,    15,     4,     5,   168,     6,     7,     8,     9,
      10,    11,   169,    12,    13,    14,   375,   290,   291,    15,
     507,   508,   509,   510,   175,    96,    97,   545,    17,   231,
      18,    19,    20,    21,    22,    23,    24,    25,    26,   474,
      27,   475,    16,   320,   321,    86,   238,    87,    19,    20,
      21,    22,    23,    24,    25,    26,   253,    88,   507,   508,
     509,   510,   381,   382,   286,   438,   439,   440,   507,   508,
     509,   510,   564,   251,   154,   233,   234,   235,   236,    28,
      98,    30,   569,   409,   410,    31,   269,    32,   270,    33,
      99,   271,   100,   533,   534,   273,    28,    89,    30,   509,
     510,   100,    31,   272,    32,    90,    33,     4,     5,   287,
       6,     7,     8,     9,    10,    11,   293,    12,    13,    14,
     294,   516,   517,    15,     4,     5,   288,     6,     7,     8,
       9,    10,    11,   295,    12,    13,    14,    95,   568,   534,
      15,   514,   515,   516,   517,   296,    16,   297,   550,    17,
     298,    18,    19,    20,    21,    22,    23,    24,    25,    26,
     518,    27,   137,    16,   388,   389,    17,   299,    18,    19,
      20,    21,    22,    23,    24,    25,    26,   300,    27,   301,
     302,   115,   116,   117,   118,   119,   303,     4,     5,   572,
       6,     7,     8,     9,    10,    11,   345,    12,    13,    14,
      28,    29,    30,    15,   304,   349,    31,   305,    32,   306,
      33,   115,   116,   117,   118,   119,   307,    28,    98,    30,
     308,   309,   310,    31,   256,    32,    16,    33,   311,    17,
     314,    18,    19,    20,    21,    22,    23,    24,    25,    26,
     313,    27,   115,   116,   117,   118,   119,   315,   316,   327,
     567,   317,     4,     5,   318,     6,     7,     8,     9,    10,
      11,   319,    12,    13,    14,   322,   323,   324,   148,   328,
     115,   116,   117,   118,   119,   116,   117,   118,   119,   330,
      28,    29,    30,   468,   331,   332,    31,   333,    32,   336,
      33,    16,   338,   339,    17,   340,    18,    19,    20,    21,
      22,    23,    24,    25,    26,   341,    27,   404,   405,   406,
     407,   507,   508,   509,   510,     4,     5,   347,     6,     7,
       8,     9,    10,    11,   342,    12,    13,    14,   343,   365,
     351,    15,     4,     5,   350,     6,     7,     8,     9,    10,
      11,   352,    12,    13,    14,    28,    29,    30,   488,   376,
     353,    31,    16,    32,    16,    33,   370,    17,   379,    18,
      19,    20,    21,    22,    23,    24,    25,    26,   380,    27,
     390,    16,   391,   412,    17,   402,    18,    19,    20,    21,
      22,    23,    24,    25,    26,   403,    27,   115,   116,   117,
     118,   119,   514,   515,   516,   517,   394,   395,   398,   400,
     558,   418,   419,   421,   423,   424,   427,   428,    28,    98,
      30,   429,   467,   478,    31,   491,    32,   490,    33,   180,
     181,   469,   470,   471,   472,    28,    29,    30,   473,   476,
     477,    31,   492,    32,   493,    33,   182,   183,   184,   185,
     186,   479,   480,   187,   188,   189,   190,   191,   192,   193,
     194,   486,   487,   496,   500,   195,   525,   196,   497,   503,
     529,   502,   531,   182,   183,   184,   185,   186,   519,   197,
     187,   188,   189,   190,   191,   192,   193,   194,   520,   521,
     522,   523,   536,   524,   526,   527,   528,   198,   199,   200,
     201,   202,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,   532,   535,   541,   542,   566,   559,   560,
     145,   203,   489,   255,   198,   199,   200,   201,   207,   208,
     209,   210,   211,   212,   213,   214,   215,   216,   281,   563,
     562,   530,   280,   230,     0,     0,   282,     0,     0,   283
};

static const yytype_int16 yycheck[] =
{
      28,    29,    14,    31,    90,     1,   341,   121,   293,    17,
     339,   313,    17,    33,   343,    18,    17,    30,    31,    31,
     321,   306,    60,    25,   340,   341,   342,    96,    55,    55,
      55,   316,    32,   318,    32,    31,    55,    33,    32,    32,
     108,    77,    78,    19,    20,    32,    72,    75,    30,    31,
      59,    58,    55,    60,    17,   114,   124,    58,    58,    60,
      58,    89,    70,   122,    61,    70,    60,    60,    80,    70,
      98,   157,   100,    60,    55,     0,    32,    58,    90,    55,
     118,    57,    79,    17,   111,   111,   111,   115,   116,   117,
     118,   119,   111,    69,   115,   108,   109,   110,   111,   112,
     109,   110,    55,   116,    60,    58,   115,    70,   111,   110,
     118,   118,    34,   118,   116,    61,   144,    57,   118,   155,
     118,    25,   158,   458,   459,   118,   108,   109,   110,   111,
     112,   118,    78,    79,   119,   111,    70,   453,   454,   120,
     115,   169,   458,   459,   115,   157,   166,    55,    36,    37,
      38,    39,    40,   120,   121,    43,    44,    45,    46,    47,
      48,    49,    50,   115,    72,    14,   162,    55,   164,   109,
     110,   167,   115,   287,   503,   115,   121,    85,    86,   514,
     515,   516,   517,    57,   500,    59,    25,   273,    55,   275,
      17,   507,   508,   509,   510,   497,    55,   498,   499,    87,
      88,    89,    90,    91,    25,    72,    33,   120,   121,   204,
     116,   116,    61,    72,   116,   121,   121,   552,   553,   121,
     120,   121,   217,   111,   116,   541,    75,   116,   256,   121,
      79,    25,   121,   116,   229,   109,   110,   232,   121,    55,
      56,   115,   237,    70,   239,   111,   112,   532,   243,    25,
     108,   109,   110,   111,   112,   250,    80,    81,    82,    83,
      84,   273,   115,   275,   260,   123,    16,    17,    34,    19,
      20,    21,    22,    23,    24,    34,    26,    27,    28,    29,
     366,   566,    32,    16,    17,    55,    19,    20,    21,    22,
      23,    24,   115,    26,    27,    28,   292,    34,    35,    32,
     109,   110,   111,   112,    31,    55,    56,   116,    58,    55,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    58,
      70,    60,    55,    34,    35,    58,    55,    60,    61,    62,
      63,    64,    65,    66,    67,    68,   115,    70,   109,   110,
     111,   112,    73,    74,   372,   331,   332,   333,   109,   110,
     111,   112,   123,    69,   366,    51,    52,    53,    54,   109,
     110,   111,   123,    14,    15,   115,    25,   117,    25,   119,
     120,    25,   122,   120,   121,    25,   109,   110,   111,   111,
     112,   122,   115,    32,   117,   118,   119,    16,    17,   114,
      19,    20,    21,    22,    23,    24,    34,    26,    27,    28,
      34,   111,   112,    32,    16,    17,   125,    19,    20,    21,
      22,    23,    24,    34,    26,    27,    28,    29,   120,   121,
      32,   109,   110,   111,   112,    34,    55,    34,   116,    58,
      34,    60,    61,    62,    63,    64,    65,    66,    67,    68,
     468,    70,    71,    55,   298,   299,    58,    34,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    34,    70,    34,
      34,   108,   109,   110,   111,   112,    34,    16,    17,   116,
      19,    20,    21,    22,    23,    24,    58,    26,    27,    28,
     109,   110,   111,    32,    34,   116,   115,    34,   117,    34,
     119,   108,   109,   110,   111,   112,    34,   109,   110,   111,
      34,    34,    34,   115,   121,   117,    55,   119,    34,    58,
      34,    60,    61,    62,    63,    64,    65,    66,    67,    68,
     114,    70,   108,   109,   110,   111,   112,    34,    34,   114,
     558,    34,    16,    17,    34,    19,    20,    21,    22,    23,
      24,    34,    26,    27,    28,    34,    34,    34,    32,   114,
     108,   109,   110,   111,   112,   109,   110,   111,   112,    34,
     109,   110,   111,   121,    34,    34,   115,    34,   117,    34,
     119,    55,    34,    34,    58,    34,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    34,    70,    92,    93,    94,
      95,   109,   110,   111,   112,    16,    17,    71,    19,    20,
      21,    22,    23,    24,    34,    26,    27,    28,    34,    25,
      58,    32,    16,    17,   116,    19,    20,    21,    22,    23,
      24,   116,    26,    27,    28,   109,   110,   111,    32,    69,
     116,   115,    55,   117,    55,   119,   116,    58,    57,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    76,    70,
      77,    55,    77,   119,    58,    57,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    57,    70,   108,   109,   110,
     111,   112,   109,   110,   111,   112,   302,   303,   304,   305,
     121,    61,    61,    61,    61,   107,    61,    61,   109,   110,
     111,    61,   116,    58,   115,   124,   117,   108,   119,    19,
      20,   116,   116,   116,   116,   109,   110,   111,   116,   116,
     116,   115,   115,   117,    55,   119,    36,    37,    38,    39,
      40,   116,   116,    43,    44,    45,    46,    47,    48,    49,
      50,   116,   116,    34,   122,    55,    60,    57,   114,   121,
      69,   114,    57,    36,    37,    38,    39,    40,   116,    69,
      43,    44,    45,    46,    47,    48,    49,    50,   116,   116,
     116,   116,    55,   116,   116,   116,   116,    87,    88,    89,
      90,    91,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    34,   119,   122,    55,    34,   116,   116,
      80,   111,   372,   133,    87,    88,    89,    90,    97,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   162,   535,
     534,   491,   161,   124,    -1,    -1,   164,    -1,    -1,   166
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    96,   127,   128,    16,    17,    19,    20,    21,    22,
      23,    24,    26,    27,    28,    32,    55,    58,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    70,   109,   110,
     111,   115,   117,   119,   134,   135,   138,   139,   140,   142,
     143,   144,   147,   152,   153,   154,   155,   157,   158,   161,
       0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,   129,   130,   172,   187,   201,   209,   212,   216,
     223,   228,   232,   235,   119,   115,   115,   115,   115,    17,
      33,    70,   141,   157,   138,   138,    58,    60,    70,   110,
     118,   135,   138,   156,   157,    29,    55,    56,   110,   120,
     122,   135,   162,   164,   165,   166,   167,   168,   169,   170,
     171,   114,   171,    30,    31,   108,   109,   110,   111,   112,
     136,   131,   173,   188,   202,   210,   213,   217,   224,   229,
     233,    55,    58,   148,   149,   150,   151,    71,   138,   159,
     135,   163,   163,   163,   115,   141,    25,    25,    32,    58,
      60,    70,   110,   156,   157,   121,   116,    25,   115,   138,
     120,   121,    34,   120,   121,   120,   121,    34,    55,   115,
     138,   138,   138,   138,   138,    31,   111,   132,   133,   134,
      19,    20,    36,    37,    38,    39,    40,    43,    44,    45,
      46,    47,    48,    49,    50,    55,    57,    69,    87,    88,
      89,    90,    91,   111,   174,   178,   204,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   189,   190,   191,
     192,   193,   194,   195,   196,   198,   199,   200,    55,   203,
     204,    55,   211,    51,    52,    53,    54,   214,    55,   218,
     219,    55,   111,   225,   226,    80,    81,    82,    83,    84,
     230,    69,   234,   115,   120,   149,   121,   116,   121,   116,
     121,   116,   116,    32,    58,   118,    32,    60,   118,    25,
      25,    25,    32,    25,   163,   118,   156,   163,   123,    55,
     165,   162,   168,   170,   135,   137,   138,   114,   125,   237,
      34,    35,   236,    34,    34,    34,    34,    34,    34,    34,
      34,    34,    34,    34,    34,    34,    34,    34,    34,    34,
      34,    34,   237,   114,    34,    34,    34,    34,    34,    34,
      34,    35,    34,    34,    34,   237,   237,   114,   114,   237,
      34,    34,    34,    34,   237,   237,    34,   237,    34,    34,
      34,    34,    34,    34,   237,    58,   138,    71,   135,   116,
     116,    58,   116,   116,    32,    60,    58,    60,   118,    32,
      58,   118,    32,    60,   118,    25,   118,   156,   116,   156,
     116,   116,    25,   116,   134,   135,    69,   160,   181,    57,
      76,    73,    74,   182,   183,    61,    79,   185,   183,   183,
      77,    77,    78,   184,   185,   185,    14,    75,   185,   186,
     185,   160,    57,    57,    92,    93,    94,    95,   180,    14,
      15,   179,   119,    55,    91,   111,   177,   178,    61,    61,
     160,    61,   160,    61,   107,   197,   197,    61,    61,    61,
      55,   111,   205,    18,    55,   111,   160,   215,   215,   215,
     215,    55,    72,   111,   220,   221,   222,    55,    72,   227,
     222,    57,   109,   110,   115,   145,    59,   109,   110,   115,
     145,   146,   231,   145,    85,    86,   222,   116,   121,   116,
     116,   116,   116,   116,    58,    60,   116,   116,    58,   116,
     116,    32,    60,    60,   118,   156,   116,   116,    32,   137,
     108,   124,   115,    55,   175,   176,    34,   114,   108,   124,
     122,   206,   114,   121,   145,   145,   145,   109,   110,   111,
     112,   146,   146,   146,   109,   110,   111,   112,   138,   116,
     116,   116,   116,   116,   116,    60,   116,   116,   116,    69,
     182,    57,    34,   120,   121,   119,    55,   178,   197,   197,
     145,   122,    55,   207,   222,   116,   145,   145,   145,   145,
     116,   109,   110,   115,   146,   146,   146,   146,   121,   116,
     116,   160,   176,   175,   123,   145,    34,   138,   120,   123,
     160,   208,   116
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,   126,   127,   127,   128,   128,   129,   129,   129,   129,
     129,   129,   129,   129,   129,   129,   129,   130,   131,   131,
     132,   133,   133,   134,   134,   134,   135,   135,   135,   135,
     136,   136,   136,   137,   138,   138,   138,   138,   138,   138,
     138,   138,   138,   138,   139,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   141,   141,   142,   142,   142,   142,   142,   142,
     142,   142,   143,   143,   143,   143,   143,   143,   143,   143,
     143,   143,   143,   143,   144,   144,   144,   144,   145,   145,
     145,   145,   145,   145,   145,   145,   146,   146,   146,   146,
     146,   146,   146,   146,   147,   148,   148,   149,   149,   150,
     151,   152,   153,   154,   155,   155,   156,   156,   157,   158,
     159,   159,   160,   160,   161,   161,   161,   161,   161,   161,
     161,   161,   162,   162,   163,   163,   164,   164,   165,   166,
     166,   167,   167,   168,   168,   169,   169,   170,   171,   172,
     173,   173,   174,   174,   174,   174,   174,   175,   175,   176,
     176,   177,   177,   178,   178,   178,   178,   178,   178,   178,
     178,   178,   178,   178,   178,   178,   178,   178,   178,   178,
     178,   179,   179,   180,   180,   180,   180,   180,   181,   182,
     182,   183,   183,   184,   184,   185,   185,   186,   186,   186,
     187,   188,   188,   189,   189,   189,   189,   189,   189,   189,
     189,   189,   189,   190,   191,   192,   193,   194,   195,   196,
     196,   197,   197,   197,   198,   199,   200,   201,   202,   202,
     203,   204,   204,   204,   204,   204,   204,   205,   205,   205,
     206,   206,   207,   208,   209,   210,   210,   211,   211,   211,
     211,   212,   213,   213,   214,   214,   214,   214,   215,   216,
     217,   217,   218,   219,   220,   220,   221,   221,   222,   222,
     223,   224,   224,   225,   226,   226,   227,   227,   228,   229,
     229,   230,   230,   230,   230,   230,   230,   230,   231,   231,
     232,   233,   233,   234,   235,   236,   236,   237,   237
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     0,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     0,     3,
       3,     1,     3,     3,     2,     1,     1,     2,     2,     3,
       4,     6,     6,     1,     1,     1,     3,     2,     2,     3,
       3,     3,     3,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     3,     1,     1,
       1,     1,     1,     1,     6,     7,     5,     6,     6,     7,
       5,     6,     6,     7,     7,     8,     5,     6,     6,     7,
       5,     6,     6,     7,     5,     6,     6,     7,     1,     3,
       2,     2,     3,     3,     3,     3,     1,     3,     2,     2,
       3,     3,     3,     3,     4,     1,     2,     1,     1,     1,
       4,     1,     1,     1,     1,     1,     1,     1,    10,     4,
       1,     3,     1,     3,     2,     3,     3,     3,     5,     4,
       4,     4,     1,     1,     1,     3,     1,     3,     3,     1,
       1,     1,     3,     1,     4,     1,     3,     3,     3,     2,
       0,     3,     1,     3,     5,     5,     7,     1,     3,     1,
       3,     1,     1,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     1,     1,     1,     1,     1,     4,     1,     1,     1,
       1,     1,     3,     1,     1,     1,     1,     1,     1,     1,
       2,     0,     3,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     3,     3,     3,     3,     3,     3,     3,
       3,     1,     3,     3,     3,     3,     3,     2,     0,     3,
       7,     1,     1,     1,     1,     1,     1,     1,     2,     1,
       3,     4,     1,     1,     2,     0,     3,     1,     3,     3,
       3,     2,     0,     3,     3,     3,     3,     3,     1,     2,
       0,     3,     3,     1,     1,     1,     1,     3,     1,     1,
       2,     0,     3,     3,     1,     1,     1,     1,     2,     0,
       3,     3,     3,     3,     3,     3,     3,     3,     1,     1,
       2,     0,     2,     1,     1,     1,     1,     0,     1
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  switch (yytype)
    {
          case 55: /* Identifier  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1718 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 56: /* "ASN.1 identifier beginning with a lowercase letter"  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1724 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 57: /* Number  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).int_val); }
#line 1730 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 58: /* "integer value"  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).int_val); }
#line 1736 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 63: /* "bit string value"  */
#line 332 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).bitstring_val).bits_ptr); }
#line 1742 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 64: /* "hex string value"  */
#line 336 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).hexstring_val).nibbles_ptr); }
#line 1748 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 65: /* "octet string value"  */
#line 340 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).octetstring_val).octets_ptr); }
#line 1754 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 66: /* "bit string template"  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1760 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 67: /* "hex string template"  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1766 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 68: /* "octet string template"  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1772 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 69: /* Cstring  */
#line 344 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).charstring_val).chars_ptr); }
#line 1778 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 70: /* "charstring value"  */
#line 344 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).charstring_val).chars_ptr); }
#line 1784 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 133: /* ParameterName  */
#line 387 "config_process.y" /* yacc.c:1257  */
      { for(size_t i=0; i<((*yyvaluep).name_vector)->size(); i++) { Free(((*yyvaluep).name_vector)->at(i)); } delete ((*yyvaluep).name_vector); }
#line 1790 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 134: /* ParameterNameSegment  */
#line 387 "config_process.y" /* yacc.c:1257  */
      { for(size_t i=0; i<((*yyvaluep).name_vector)->size(); i++) { Free(((*yyvaluep).name_vector)->at(i)); } delete ((*yyvaluep).name_vector); }
#line 1796 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 135: /* ParameterValue  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1802 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 136: /* LengthMatch  */
#line 381 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_length_restriction); }
#line 1808 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 138: /* ParameterExpression  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1814 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 139: /* ParameterReference  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1820 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 140: /* SimpleParameterValue  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1826 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 141: /* PatternChunk  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1832 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 142: /* IntegerRange  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1838 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 143: /* FloatRange  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1844 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 144: /* StringRange  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1850 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 145: /* IntegerValue  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).int_val); }
#line 1856 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 147: /* ObjIdValue  */
#line 328 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).objid_val).components_ptr); }
#line 1862 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 148: /* ObjIdComponentList  */
#line 328 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).objid_val).components_ptr); }
#line 1868 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 149: /* ObjIdComponent  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).int_val); }
#line 1874 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 150: /* NumberForm  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).int_val); }
#line 1880 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 151: /* NameAndNumberForm  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).int_val); }
#line 1886 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 152: /* BitstringValue  */
#line 332 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).bitstring_val).bits_ptr); }
#line 1892 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 153: /* HexstringValue  */
#line 336 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).hexstring_val).nibbles_ptr); }
#line 1898 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 154: /* OctetstringValue  */
#line 340 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).octetstring_val).octets_ptr); }
#line 1904 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 155: /* UniversalCharstringValue  */
#line 348 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).universal_charstring_val).uchars_ptr); }
#line 1910 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 156: /* UniversalCharstringFragment  */
#line 348 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).universal_charstring_val).uchars_ptr); }
#line 1916 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 160: /* StringValue  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1922 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 161: /* CompoundValue  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1928 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 162: /* ParameterValueOrNotUsedSymbol  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1934 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 163: /* TemplateItemList  */
#line 384 "config_process.y" /* yacc.c:1257  */
      { for(size_t i=0; i<((*yyvaluep).module_param_list)->size(); i++) { delete ((*yyvaluep).module_param_list)->at(i); } delete ((*yyvaluep).module_param_list); }
#line 1940 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 164: /* FieldValueList  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1946 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 165: /* FieldValue  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1952 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 166: /* FieldName  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1958 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 167: /* ArrayItemList  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1964 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 168: /* ArrayItem  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1970 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 169: /* IndexItemList  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1976 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 170: /* IndexItem  */
#line 358 "config_process.y" /* yacc.c:1257  */
      { delete ((*yyvaluep).module_param_val); }
#line 1982 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 181: /* LogFileName  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 1988 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 204: /* ComponentId  */
#line 352 "config_process.y" /* yacc.c:1257  */
      { if (((*yyvaluep).comp_id).id_selector == COMPONENT_ID_NAME) Free(((*yyvaluep).comp_id).id_name); }
#line 1994 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 205: /* TestportName  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 2000 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 206: /* ArrayRef  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 2006 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 207: /* TestportParameterName  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 2012 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 208: /* TestportParameterValue  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 2018 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 211: /* ExecuteItem  */
#line 355 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).execute_item_val).module_name); Free(((*yyvaluep).execute_item_val).testcase_name); }
#line 2024 "config_process.tab.cc" /* yacc.c:1257  */
        break;

    case 215: /* Command  */
#line 312 "config_process.y" /* yacc.c:1257  */
      { Free(((*yyvaluep).str_val)); }
#line 2030 "config_process.tab.cc" /* yacc.c:1257  */
        break;


      default:
        break;
    }
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 411 "config_process.y" /* yacc.c:1646  */
    {
    if (Ttcn_String_Parsing::happening() || Debugger_Value_Parsing::happening()) {
      config_process_error("Config file cannot be parsed as ttcn string");
    }
  }
#line 2298 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 3:
#line 417 "config_process.y" /* yacc.c:1646  */
    {
    parsed_module_param = (yyvsp[0].module_param_val);
  }
#line 2306 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 20:
#line 452 "config_process.y" /* yacc.c:1646  */
    {
  Module_Param* mp = (yyvsp[0].module_param_val);
  mp->set_id(new Module_Param_Name(*(yyvsp[-2].name_vector)));
  mp->set_operation_type((yyvsp[-1].param_optype_val));
  set_param(*mp);
  delete mp;
  delete (yyvsp[-2].name_vector);
}
#line 2319 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 21:
#line 463 "config_process.y" /* yacc.c:1646  */
    { (yyval.name_vector) = (yyvsp[0].name_vector); }
#line 2325 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 22:
#line 464 "config_process.y" /* yacc.c:1646  */
    { (yyval.name_vector) = (yyvsp[0].name_vector); }
#line 2331 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 23:
#line 469 "config_process.y" /* yacc.c:1646  */
    {
  (yyval.name_vector) = (yyvsp[-2].name_vector);
  (yyval.name_vector)->push_back((yyvsp[0].str_val));
}
#line 2340 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 24:
#line 474 "config_process.y" /* yacc.c:1646  */
    {
  (yyval.name_vector) = (yyvsp[-1].name_vector);
  (yyval.name_vector)->push_back(mprintf("%d", (yyvsp[0].int_native)));
}
#line 2349 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 25:
#line 479 "config_process.y" /* yacc.c:1646  */
    {
  (yyval.name_vector) = new Vector<char*>();
  (yyval.name_vector)->push_back((yyvsp[0].str_val)); 
}
#line 2358 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 26:
#line 487 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
  }
#line 2366 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 27:
#line 491 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-1].module_param_val);
    (yyval.module_param_val)->set_length_restriction((yyvsp[0].module_param_length_restriction));
  }
#line 2375 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 28:
#line 496 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-1].module_param_val);
    (yyval.module_param_val)->set_ifpresent();
  }
#line 2384 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 29:
#line 501 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-2].module_param_val);
    (yyval.module_param_val)->set_length_restriction((yyvsp[-1].module_param_length_restriction));
    (yyval.module_param_val)->set_ifpresent();
  }
#line 2394 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 30:
#line 510 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_length_restriction) = new Module_Param_Length_Restriction();
    (yyval.module_param_length_restriction)->set_single((size_t)(yyvsp[-1].int_native));
  }
#line 2403 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 31:
#line 515 "config_process.y" /* yacc.c:1646  */
    {
    if ((yyvsp[-3].int_native)>(yyvsp[-1].int_native)) {
      config_process_error("invalid length restriction: lower bound > upper bound");
    }
    (yyval.module_param_length_restriction) = new Module_Param_Length_Restriction();
    (yyval.module_param_length_restriction)->set_min((size_t)(yyvsp[-3].int_native));
    (yyval.module_param_length_restriction)->set_max((size_t)(yyvsp[-1].int_native));
  }
#line 2416 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 32:
#line 524 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_length_restriction) = new Module_Param_Length_Restriction();
    (yyval.module_param_length_restriction)->set_min((size_t)(yyvsp[-3].int_native));
  }
#line 2425 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 33:
#line 532 "config_process.y" /* yacc.c:1646  */
    {
  (yyvsp[0].module_param_val)->set_id(new Module_Param_CustomName(mcopystr("length bound")));
  INTEGER tmp;
  tmp.set_param(*(yyvsp[0].module_param_val));
  if (!tmp.get_val().is_native()) {
    config_process_error("bignum length restriction bound.");
    (yyval.int_native) = 0;
  } else if (tmp.get_val().is_negative()) {
    config_process_error("negative length restriction bound.");
    (yyval.int_native) = 0;
  } else {
    (yyval.int_native) = tmp;
  }
  delete (yyvsp[0].module_param_val);
}
#line 2445 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 34:
#line 552 "config_process.y" /* yacc.c:1646  */
    { (yyval.module_param_val) = (yyvsp[0].module_param_val); }
#line 2451 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 35:
#line 553 "config_process.y" /* yacc.c:1646  */
    { (yyval.module_param_val) = (yyvsp[0].module_param_val); }
#line 2457 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 36:
#line 554 "config_process.y" /* yacc.c:1646  */
    { (yyval.module_param_val) = (yyvsp[-1].module_param_val); }
#line 2463 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 37:
#line 555 "config_process.y" /* yacc.c:1646  */
    { (yyval.module_param_val) = (yyvsp[0].module_param_val); }
#line 2469 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 38:
#line 556 "config_process.y" /* yacc.c:1646  */
    { (yyval.module_param_val) = new Module_Param_Expression((yyvsp[0].module_param_val)); }
#line 2475 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 39:
#line 558 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Expression(Module_Param::EXPR_ADD, (yyvsp[-2].module_param_val), (yyvsp[0].module_param_val));
  }
#line 2483 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 40:
#line 562 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Expression(Module_Param::EXPR_SUBTRACT, (yyvsp[-2].module_param_val), (yyvsp[0].module_param_val));
  }
#line 2491 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 41:
#line 566 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Expression(Module_Param::EXPR_MULTIPLY, (yyvsp[-2].module_param_val), (yyvsp[0].module_param_val));
  }
#line 2499 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 42:
#line 570 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Expression(Module_Param::EXPR_DIVIDE, (yyvsp[-2].module_param_val), (yyvsp[0].module_param_val));
  }
#line 2507 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 43:
#line 574 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Expression(Module_Param::EXPR_CONCATENATE, (yyvsp[-2].module_param_val), (yyvsp[0].module_param_val));
  }
#line 2515 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 44:
#line 583 "config_process.y" /* yacc.c:1646  */
    {
#ifdef TITAN_RUNTIME_2
    (yyval.module_param_val) = new Module_Param_Reference(new Module_Param_Name(*(yyvsp[0].name_vector)));
#else
    // no references allowed in RT1, so the name segment must be an enumerated value
    // (which means it can only contain 1 name)
    if ((yyvsp[0].name_vector)->size() != 1) {
      config_process_error("Module parameter references are not allowed in the "
        "Load Test Runtime.");
    }
    (yyval.module_param_val) = new Module_Param_Enumerated((yyvsp[0].name_vector)->front());
#endif
    delete (yyvsp[0].name_vector);
  }
#line 2534 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 45:
#line 601 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Integer((yyvsp[0].int_val));
  }
#line 2542 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 46:
#line 605 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Float((yyvsp[0].float_val));
  }
#line 2550 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 47:
#line 609 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Float(INFINITY);
  }
#line 2558 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 48:
#line 613 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Boolean((yyvsp[0].bool_val));
  }
#line 2566 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 49:
#line 617 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Objid((yyvsp[0].objid_val).n_components, (yyvsp[0].objid_val).components_ptr);
  }
#line 2574 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 50:
#line 621 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Verdict((yyvsp[0].verdict_val));
  }
#line 2582 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 51:
#line 625 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Bitstring((yyvsp[0].bitstring_val).n_bits, (yyvsp[0].bitstring_val).bits_ptr);
  }
#line 2590 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 52:
#line 629 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Hexstring((yyvsp[0].hexstring_val).n_nibbles, (yyvsp[0].hexstring_val).nibbles_ptr);
  }
#line 2598 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 53:
#line 633 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Octetstring((yyvsp[0].octetstring_val).n_octets, (yyvsp[0].octetstring_val).octets_ptr);
  }
#line 2606 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 54:
#line 637 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Charstring((yyvsp[0].charstring_val).n_chars, (yyvsp[0].charstring_val).chars_ptr);
  }
#line 2614 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 55:
#line 641 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Universal_Charstring((yyvsp[0].universal_charstring_val).n_uchars, (yyvsp[0].universal_charstring_val).uchars_ptr);
  }
#line 2622 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 56:
#line 645 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Omit();
  }
#line 2630 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 57:
#line 649 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Asn_Null();
  }
#line 2638 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 58:
#line 653 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Ttcn_Null();
  }
#line 2646 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 59:
#line 657 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Ttcn_mtc();
  }
#line 2654 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 60:
#line 661 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Ttcn_system();
  }
#line 2662 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 61:
#line 665 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Any();
  }
#line 2670 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 62:
#line 669 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_AnyOrNone();
  }
#line 2678 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 63:
#line 673 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
  }
#line 2686 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 64:
#line 677 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
  }
#line 2694 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 65:
#line 681 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
  }
#line 2702 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 66:
#line 685 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Pattern((yyvsp[0].str_val), FALSE);
  }
#line 2710 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 67:
#line 689 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Pattern((yyvsp[0].str_val), TRUE);
  }
#line 2718 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 68:
#line 693 "config_process.y" /* yacc.c:1646  */
    {
    // conversion
    int n_chars = (int)mstrlen((yyvsp[0].str_val));
    unsigned char* chars_ptr = (unsigned char*)Malloc(n_chars*sizeof(unsigned char));
    for (int i=0; i<n_chars; i++) {
      switch ((yyvsp[0].str_val)[i]) {
      case '0':
        chars_ptr[i] = 0;
        break;
      case '1':
        chars_ptr[i] = 1;
        break;
      case '?':
        chars_ptr[i] = 2;
        break;
      case '*':
        chars_ptr[i] = 3;
        break;
      default:
        chars_ptr[i] = 0;
        config_process_error_f("Invalid char (%c) in bitstring template", (yyvsp[0].str_val)[i]);
      }
    }
    Free((yyvsp[0].str_val));
    (yyval.module_param_val) = new Module_Param_Bitstring_Template(n_chars, chars_ptr);
  }
#line 2749 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 69:
#line 720 "config_process.y" /* yacc.c:1646  */
    {
    int n_chars = (int)mstrlen((yyvsp[0].str_val));
    unsigned char* chars_ptr = (unsigned char*)Malloc(n_chars*sizeof(unsigned char));
    for (int i=0; i<n_chars; i++) {
      if ((yyvsp[0].str_val)[i]=='?') chars_ptr[i] = 16;
      else if ((yyvsp[0].str_val)[i]=='*') chars_ptr[i] = 17;
      else chars_ptr[i] = char_to_hexdigit_((yyvsp[0].str_val)[i]);
    }
    Free((yyvsp[0].str_val));
    (yyval.module_param_val) = new Module_Param_Hexstring_Template(n_chars, chars_ptr);
  }
#line 2765 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 70:
#line 732 "config_process.y" /* yacc.c:1646  */
    {
    Vector<unsigned short> octet_vec;
    int str_len = (int)mstrlen((yyvsp[0].str_val));
    for (int i=0; i<str_len; i++) {
      unsigned short num;
      if ((yyvsp[0].str_val)[i]=='?') num = 256;
      else if ((yyvsp[0].str_val)[i]=='*') num = 257;
      else {
        // first digit
        num = 16 * char_to_hexdigit_((yyvsp[0].str_val)[i]);
        i++;
        if (i>=str_len) config_process_error("Unexpected end of octetstring pattern");
        // second digit
        num += char_to_hexdigit_((yyvsp[0].str_val)[i]);
      }
      octet_vec.push_back(num);
    }
    Free((yyvsp[0].str_val));
    int n_chars = (int)octet_vec.size();
    unsigned short* chars_ptr = (unsigned short*)Malloc(n_chars*sizeof(unsigned short));
    for (int i=0; i<n_chars; i++) chars_ptr[i] = octet_vec[i];
    (yyval.module_param_val) = new Module_Param_Octetstring_Template(n_chars, chars_ptr);
  }
#line 2793 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 71:
#line 756 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
  }
#line 2801 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 72:
#line 763 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.str_val) = mcopystr((yyvsp[0].charstring_val).chars_ptr);
    Free((yyvsp[0].charstring_val).chars_ptr);
  }
#line 2810 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 73:
#line 768 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.str_val) = mprintf("\\q{%d,%d,%d,%d}", (yyvsp[0].universal_char_val).uc_group, (yyvsp[0].universal_char_val).uc_plane, (yyvsp[0].universal_char_val).uc_row, (yyvsp[0].universal_char_val).uc_cell);
  }
#line 2818 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 74:
#line 775 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_IntRange(NULL, (yyvsp[-1].int_val), false, false);
  }
#line 2826 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 75:
#line 779 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_IntRange(NULL, (yyvsp[-1].int_val), false, true);
  }
#line 2834 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 76:
#line 783 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_IntRange((yyvsp[-3].int_val), (yyvsp[-1].int_val), false, false);
  }
#line 2842 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 77:
#line 787 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_IntRange((yyvsp[-3].int_val), (yyvsp[-1].int_val), true, false);
  }
#line 2850 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 78:
#line 791 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_IntRange((yyvsp[-4].int_val), (yyvsp[-1].int_val), false, true);
  }
#line 2858 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 79:
#line 795 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_IntRange((yyvsp[-4].int_val), (yyvsp[-1].int_val), true, true);
  }
#line 2866 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 80:
#line 799 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_IntRange((yyvsp[-3].int_val), NULL, false, false);
  }
#line 2874 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 81:
#line 803 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_IntRange((yyvsp[-3].int_val), NULL, true, false);
  }
#line 2882 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 82:
#line 810 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange(0.0, false, (yyvsp[-1].float_val), true, false, false);
  }
#line 2890 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 83:
#line 814 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange(0.0, false, (yyvsp[-1].float_val), true, true, false);
  }
#line 2898 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 84:
#line 818 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange(0.0, false, (yyvsp[-1].float_val), true, false, true);
  }
#line 2906 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 85:
#line 822 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange(0.0, false, (yyvsp[-1].float_val), true, true, true);
  }
#line 2914 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 86:
#line 826 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange((yyvsp[-3].float_val), true, (yyvsp[-1].float_val), true, false, false);
  }
#line 2922 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 87:
#line 830 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange((yyvsp[-3].float_val), true, (yyvsp[-1].float_val), true, true, false);
  }
#line 2930 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 88:
#line 834 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange((yyvsp[-4].float_val), true, (yyvsp[-1].float_val), true, false, true);
  }
#line 2938 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 89:
#line 838 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange((yyvsp[-4].float_val), true, (yyvsp[-1].float_val), true, true, true);
  }
#line 2946 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 90:
#line 842 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange((yyvsp[-3].float_val), true, 0.0, false, false, false);
  }
#line 2954 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 91:
#line 846 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange((yyvsp[-3].float_val), true, 0.0, false, true, false);
  }
#line 2962 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 92:
#line 850 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange((yyvsp[-4].float_val), true, 0.0, false, false, true);
  }
#line 2970 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 93:
#line 854 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_FloatRange((yyvsp[-4].float_val), true, 0.0, false, true, true);
  }
#line 2978 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 94:
#line 861 "config_process.y" /* yacc.c:1646  */
    {
    universal_char lower; lower.uc_group=lower.uc_plane=lower.uc_row=lower.uc_cell=0;
    universal_char upper; upper.uc_group=upper.uc_plane=upper.uc_row=upper.uc_cell=0;
    if ((yyvsp[-3].universal_charstring_val).n_uchars!=1) {
      config_process_error("Lower bound of char range must be 1 character only");
    } else if ((yyvsp[-1].universal_charstring_val).n_uchars!=1) {
      config_process_error("Upper bound of char range must be 1 character only");
    } else {
      lower = *((yyvsp[-3].universal_charstring_val).uchars_ptr);
      upper = *((yyvsp[-1].universal_charstring_val).uchars_ptr);
      if (upper<lower) {
        config_process_error("Lower bound is larger than upper bound in the char range");
        lower = upper;
      }
    }
    Free((yyvsp[-3].universal_charstring_val).uchars_ptr);
    Free((yyvsp[-1].universal_charstring_val).uchars_ptr);
    (yyval.module_param_val) = new Module_Param_StringRange(lower, upper, false, false);
  }
#line 3002 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 95:
#line 881 "config_process.y" /* yacc.c:1646  */
    {
    universal_char lower; lower.uc_group=lower.uc_plane=lower.uc_row=lower.uc_cell=0;
    universal_char upper; upper.uc_group=upper.uc_plane=upper.uc_row=upper.uc_cell=0;
    if ((yyvsp[-3].universal_charstring_val).n_uchars!=1) {
      config_process_error("Lower bound of char range must be 1 character only");
    } else if ((yyvsp[-1].universal_charstring_val).n_uchars!=1) {
      config_process_error("Upper bound of char range must be 1 character only");
    } else {
      lower = *((yyvsp[-3].universal_charstring_val).uchars_ptr);
      upper = *((yyvsp[-1].universal_charstring_val).uchars_ptr);
      if (upper<lower) {
        config_process_error("Lower bound is larger than upper bound in the char range");
        lower = upper;
      }
    }
    Free((yyvsp[-3].universal_charstring_val).uchars_ptr);
    Free((yyvsp[-1].universal_charstring_val).uchars_ptr);
    (yyval.module_param_val) = new Module_Param_StringRange(lower, upper, true, false);
  }
#line 3026 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 96:
#line 901 "config_process.y" /* yacc.c:1646  */
    {
    universal_char lower; lower.uc_group=lower.uc_plane=lower.uc_row=lower.uc_cell=0;
    universal_char upper; upper.uc_group=upper.uc_plane=upper.uc_row=upper.uc_cell=0;
    if ((yyvsp[-4].universal_charstring_val).n_uchars!=1) {
      config_process_error("Lower bound of char range must be 1 character only");
    } else if ((yyvsp[-1].universal_charstring_val).n_uchars!=1) {
      config_process_error("Upper bound of char range must be 1 character only");
    } else {
      lower = *((yyvsp[-4].universal_charstring_val).uchars_ptr);
      upper = *((yyvsp[-1].universal_charstring_val).uchars_ptr);
      if (upper<lower) {
        config_process_error("Lower bound is larger than upper bound in the char range");
        lower = upper;
      }
    }
    Free((yyvsp[-4].universal_charstring_val).uchars_ptr);
    Free((yyvsp[-1].universal_charstring_val).uchars_ptr);
    (yyval.module_param_val) = new Module_Param_StringRange(lower, upper, false, true);
  }
#line 3050 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 97:
#line 921 "config_process.y" /* yacc.c:1646  */
    {
    universal_char lower; lower.uc_group=lower.uc_plane=lower.uc_row=lower.uc_cell=0;
    universal_char upper; upper.uc_group=upper.uc_plane=upper.uc_row=upper.uc_cell=0;
    if ((yyvsp[-4].universal_charstring_val).n_uchars!=1) {
      config_process_error("Lower bound of char range must be 1 character only");
    } else if ((yyvsp[-1].universal_charstring_val).n_uchars!=1) {
      config_process_error("Upper bound of char range must be 1 character only");
    } else {
      lower = *((yyvsp[-4].universal_charstring_val).uchars_ptr);
      upper = *((yyvsp[-1].universal_charstring_val).uchars_ptr);
      if (upper<lower) {
        config_process_error("Lower bound is larger than upper bound in the char range");
        lower = upper;
      }
    }
    Free((yyvsp[-4].universal_charstring_val).uchars_ptr);
    Free((yyvsp[-1].universal_charstring_val).uchars_ptr);
    (yyval.module_param_val) = new Module_Param_StringRange(lower, upper, true, true);
  }
#line 3074 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 98:
#line 944 "config_process.y" /* yacc.c:1646  */
    { (yyval.int_val) = (yyvsp[0].int_val); }
#line 3080 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 99:
#line 945 "config_process.y" /* yacc.c:1646  */
    { (yyval.int_val) = (yyvsp[-1].int_val); }
#line 3086 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 100:
#line 946 "config_process.y" /* yacc.c:1646  */
    { (yyval.int_val) = (yyvsp[0].int_val); }
#line 3092 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 101:
#line 948 "config_process.y" /* yacc.c:1646  */
    {
  INTEGER op1;
  op1.set_val(*(yyvsp[0].int_val));
  (yyval.int_val) = new int_val_t((-op1).get_val());
  delete (yyvsp[0].int_val);
}
#line 3103 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 102:
#line 955 "config_process.y" /* yacc.c:1646  */
    {
  INTEGER op1, op2;
  op1.set_val(*(yyvsp[-2].int_val));
  op2.set_val(*(yyvsp[0].int_val));
  (yyval.int_val) = new int_val_t((op1 + op2).get_val());
  delete (yyvsp[-2].int_val);
  delete (yyvsp[0].int_val);
}
#line 3116 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 103:
#line 964 "config_process.y" /* yacc.c:1646  */
    {
  INTEGER op1, op2;
  op1.set_val(*(yyvsp[-2].int_val));
  op2.set_val(*(yyvsp[0].int_val));
  (yyval.int_val) = new int_val_t((op1 - op2).get_val());
  delete (yyvsp[-2].int_val);
  delete (yyvsp[0].int_val);
}
#line 3129 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 104:
#line 973 "config_process.y" /* yacc.c:1646  */
    {
  INTEGER op1, op2;
  op1.set_val(*(yyvsp[-2].int_val));
  op2.set_val(*(yyvsp[0].int_val));
  (yyval.int_val) = new int_val_t((op1 * op2).get_val());
  delete (yyvsp[-2].int_val);
  delete (yyvsp[0].int_val);
}
#line 3142 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 105:
#line 982 "config_process.y" /* yacc.c:1646  */
    {
  if (*(yyvsp[0].int_val) == 0) {
    config_process_error("Integer division by zero.");
    (yyval.int_val) = new int_val_t((RInt)0);
    delete (yyvsp[-2].int_val);
    delete (yyvsp[0].int_val);
  } else {
    INTEGER op1, op2;
    op1.set_val(*(yyvsp[-2].int_val));
    op2.set_val(*(yyvsp[0].int_val));
    (yyval.int_val) = new int_val_t((op1 / op2).get_val());
    delete (yyvsp[-2].int_val);
    delete (yyvsp[0].int_val);
  }
}
#line 3162 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 106:
#line 1001 "config_process.y" /* yacc.c:1646  */
    { (yyval.float_val) = (yyvsp[0].float_val); }
#line 3168 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 107:
#line 1002 "config_process.y" /* yacc.c:1646  */
    { (yyval.float_val) = (yyvsp[-1].float_val); }
#line 3174 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 108:
#line 1003 "config_process.y" /* yacc.c:1646  */
    { (yyval.float_val) = (yyvsp[0].float_val); }
#line 3180 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 109:
#line 1004 "config_process.y" /* yacc.c:1646  */
    { (yyval.float_val) = -(yyvsp[0].float_val); }
#line 3186 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 110:
#line 1005 "config_process.y" /* yacc.c:1646  */
    { (yyval.float_val) = (yyvsp[-2].float_val) + (yyvsp[0].float_val); }
#line 3192 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 111:
#line 1006 "config_process.y" /* yacc.c:1646  */
    { (yyval.float_val) = (yyvsp[-2].float_val) - (yyvsp[0].float_val); }
#line 3198 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 112:
#line 1007 "config_process.y" /* yacc.c:1646  */
    { (yyval.float_val) = (yyvsp[-2].float_val) * (yyvsp[0].float_val); }
#line 3204 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 113:
#line 1009 "config_process.y" /* yacc.c:1646  */
    {
	if ((yyvsp[0].float_val) == 0.0) {
		config_process_error("Floating point division by zero.");
		(yyval.float_val) = 0.0;
	} else (yyval.float_val) = (yyvsp[-2].float_val) / (yyvsp[0].float_val);
}
#line 3215 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 114:
#line 1018 "config_process.y" /* yacc.c:1646  */
    { (yyval.objid_val) = (yyvsp[-1].objid_val); }
#line 3221 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 115:
#line 1023 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.objid_val).n_components = 1;
	(yyval.objid_val).components_ptr = (int *)Malloc(sizeof(int));
	(yyval.objid_val).components_ptr[0] = (yyvsp[0].int_val)->get_val();
	delete (yyvsp[0].int_val);
}
#line 3232 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 116:
#line 1030 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.objid_val).n_components = (yyvsp[-1].objid_val).n_components + 1;
	(yyval.objid_val).components_ptr = (int *)Realloc((yyvsp[-1].objid_val).components_ptr,
		(yyval.objid_val).n_components * sizeof(int));
	(yyval.objid_val).components_ptr[(yyval.objid_val).n_components - 1] = (yyvsp[0].int_val)->get_val();
	delete (yyvsp[0].int_val);
}
#line 3244 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 117:
#line 1040 "config_process.y" /* yacc.c:1646  */
    { (yyval.int_val) = (yyvsp[0].int_val); }
#line 3250 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 118:
#line 1041 "config_process.y" /* yacc.c:1646  */
    { (yyval.int_val) = (yyvsp[0].int_val); }
#line 3256 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 119:
#line 1045 "config_process.y" /* yacc.c:1646  */
    { (yyval.int_val) = (yyvsp[0].int_val); }
#line 3262 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 120:
#line 1050 "config_process.y" /* yacc.c:1646  */
    {
	Free((yyvsp[-3].str_val));
	(yyval.int_val) = (yyvsp[-1].int_val);
}
#line 3271 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 121:
#line 1057 "config_process.y" /* yacc.c:1646  */
    { (yyval.bitstring_val) = (yyvsp[0].bitstring_val); }
#line 3277 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 122:
#line 1061 "config_process.y" /* yacc.c:1646  */
    { (yyval.hexstring_val) = (yyvsp[0].hexstring_val); }
#line 3283 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 123:
#line 1065 "config_process.y" /* yacc.c:1646  */
    { (yyval.octetstring_val) = (yyvsp[0].octetstring_val); }
#line 3289 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 124:
#line 1070 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.universal_charstring_val).n_uchars = 1;
	(yyval.universal_charstring_val).uchars_ptr = (universal_char*)Malloc(sizeof(universal_char));
	(yyval.universal_charstring_val).uchars_ptr[0] = (yyvsp[0].universal_char_val);
}
#line 3299 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 125:
#line 1076 "config_process.y" /* yacc.c:1646  */
    {
  (yyval.universal_charstring_val).n_uchars = (yyvsp[0].uid_list).nElements;
  (yyval.universal_charstring_val).uchars_ptr = (universal_char*)Malloc((yyval.universal_charstring_val).n_uchars * sizeof(universal_char));
  for (int i = 0; i < (yyval.universal_charstring_val).n_uchars; ++i) {
    size_t offset = 1; //Always starts with u or U
    offset = (yyvsp[0].uid_list).elements[i][1] == '+' ? offset + 1 : offset; //Optional '+'

    char* p;
    unsigned long int_val = strtoul((yyvsp[0].uid_list).elements[i] + offset, &p, 16);
    if(*p != 0) {
      //Error, should not happen
      config_process_error_f("Invalid hexadecimal string %s.", (yyvsp[0].uid_list).elements[i] + offset);
    }
    
    //Fill in the quadruple
    (yyval.universal_charstring_val).uchars_ptr[i].uc_group = (int_val >> 24) & 0xFF;
    (yyval.universal_charstring_val).uchars_ptr[i].uc_plane = (int_val >> 16) & 0xFF;
    (yyval.universal_charstring_val).uchars_ptr[i].uc_row   = (int_val >> 8) & 0xFF;
    (yyval.universal_charstring_val).uchars_ptr[i].uc_cell  = int_val & 0xFF;

    Free((yyvsp[0].uid_list).elements[i]);
  }
  Free((yyvsp[0].uid_list).elements);
}
#line 3328 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 126:
#line 1104 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.universal_charstring_val).n_uchars = (yyvsp[0].charstring_val).n_chars;
	(yyval.universal_charstring_val).uchars_ptr = (universal_char*)
		Malloc((yyval.universal_charstring_val).n_uchars * sizeof(universal_char));
	for (int i = 0; i < (yyvsp[0].charstring_val).n_chars; i++) {
		(yyval.universal_charstring_val).uchars_ptr[i].uc_group = 0;
		(yyval.universal_charstring_val).uchars_ptr[i].uc_plane = 0;
		(yyval.universal_charstring_val).uchars_ptr[i].uc_row = 0;
		(yyval.universal_charstring_val).uchars_ptr[i].uc_cell = (yyvsp[0].charstring_val).chars_ptr[i];
	}
	Free((yyvsp[0].charstring_val).chars_ptr);
}
#line 3345 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 127:
#line 1117 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.universal_charstring_val).n_uchars = 1;
	(yyval.universal_charstring_val).uchars_ptr = (universal_char*)Malloc(sizeof(universal_char));
	(yyval.universal_charstring_val).uchars_ptr[0] = (yyvsp[0].universal_char_val);
}
#line 3355 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 128:
#line 1127 "config_process.y" /* yacc.c:1646  */
    {
  (yyvsp[-7].module_param_val)->set_id(new Module_Param_CustomName(mcopystr("quadruple group")));
  (yyvsp[-5].module_param_val)->set_id(new Module_Param_CustomName(mcopystr("quadruple plane")));
  (yyvsp[-3].module_param_val)->set_id(new Module_Param_CustomName(mcopystr("quadruple row")));
  (yyvsp[-1].module_param_val)->set_id(new Module_Param_CustomName(mcopystr("quadruple cell")));
  INTEGER g, p, r, c;
  g.set_param(*(yyvsp[-7].module_param_val));
  p.set_param(*(yyvsp[-5].module_param_val));
  r.set_param(*(yyvsp[-3].module_param_val));
  c.set_param(*(yyvsp[-1].module_param_val));
  if (g < 0 || g > 127) {
    char *s = g.get_val().as_string();
    config_process_error_f("The first number of quadruple (group) must be "
      "within the range 0 .. 127 instead of %s.", s);
    Free(s);
    (yyval.universal_char_val).uc_group = g < 0 ? 0 : 127;
  } else {
    (yyval.universal_char_val).uc_group = g;
  }
  if (p < 0 || p > 255) {
    char *s = p.get_val().as_string();
    config_process_error_f("The second number of quadruple (plane) must be "
      "within the range 0 .. 255 instead of %s.", s);
    Free(s);
    (yyval.universal_char_val).uc_plane = p < 0 ? 0 : 255;
  } else {
    (yyval.universal_char_val).uc_plane = p;
  }
  if (r < 0 || r > 255) {
    char *s = r.get_val().as_string();
    config_process_error_f("The third number of quadruple (row) must be "
      "within the range 0 .. 255 instead of %s.", s);
    Free(s);
    (yyval.universal_char_val).uc_row = r < 0 ? 0 : 255;
  } else {
    (yyval.universal_char_val).uc_row = r;
  }
  if (c < 0 || c > 255) {
    char *s = c.get_val().as_string();
    config_process_error_f("The fourth number of quadruple (cell) must be "
      "within the range 0 .. 255 instead of %s.", s);
    Free(s);
    (yyval.universal_char_val).uc_cell = c < 0 ? 0 : 255;
  } else {
    (yyval.universal_char_val).uc_cell = c;
  }
  delete (yyvsp[-7].module_param_val);
  delete (yyvsp[-5].module_param_val);
  delete (yyvsp[-3].module_param_val);
  delete (yyvsp[-1].module_param_val);
}
#line 3411 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 129:
#line 1182 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.uid_list) = (yyvsp[-1].uid_list);
  }
#line 3419 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 130:
#line 1189 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.uid_list).nElements = 1;
    (yyval.uid_list).elements = (char**)
      Malloc((yyval.uid_list).nElements * sizeof(*(yyval.uid_list).elements));
    (yyval.uid_list).elements[(yyval.uid_list).nElements-1] = (yyvsp[0].str_val);
  }
#line 3430 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 131:
#line 1195 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.uid_list).nElements = (yyvsp[-2].uid_list).nElements + 1;
    (yyval.uid_list).elements = (char**)
      Realloc((yyvsp[-2].uid_list).elements, ((yyval.uid_list).nElements) * sizeof(*(yyvsp[-2].uid_list).elements));
    (yyval.uid_list).elements[(yyval.uid_list).nElements-1] = (yyvsp[0].str_val);
  }
#line 3441 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 132:
#line 1206 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.str_val) = mcopystr((yyvsp[0].charstring_val).chars_ptr);
    Free((yyvsp[0].charstring_val).chars_ptr);
}
#line 3450 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 133:
#line 1211 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.str_val) = mputstr((yyvsp[-2].str_val), (yyvsp[0].charstring_val).chars_ptr);
    Free((yyvsp[0].charstring_val).chars_ptr);
}
#line 3459 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 134:
#line 1219 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Value_List();
  }
#line 3467 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 135:
#line 1223 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-1].module_param_val);
  }
#line 3475 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 136:
#line 1227 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-1].module_param_val);
  }
#line 3483 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 137:
#line 1231 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-1].module_param_val);
  }
#line 3491 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 138:
#line 1235 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_List_Template();
    (yyvsp[-3].module_param_val)->set_id(new Module_Param_Index((yyval.module_param_val)->get_size(),false));
    (yyval.module_param_val)->add_elem((yyvsp[-3].module_param_val));
    (yyval.module_param_val)->add_list_with_implicit_ids((yyvsp[-1].module_param_list));
    delete (yyvsp[-1].module_param_list);
  }
#line 3503 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 139:
#line 1243 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_ComplementList_Template();
    (yyval.module_param_val)->add_list_with_implicit_ids((yyvsp[-1].module_param_list));
    delete (yyvsp[-1].module_param_list);
  }
#line 3513 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 140:
#line 1249 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Superset_Template();
    (yyval.module_param_val)->add_list_with_implicit_ids((yyvsp[-1].module_param_list));
    delete (yyvsp[-1].module_param_list);
  }
#line 3523 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 141:
#line 1255 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Subset_Template();
    (yyval.module_param_val)->add_list_with_implicit_ids((yyvsp[-1].module_param_list));
    delete (yyvsp[-1].module_param_list);
  }
#line 3533 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 142:
#line 1264 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
  }
#line 3541 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 143:
#line 1268 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_NotUsed();
  }
#line 3549 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 144:
#line 1275 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_list) = new Vector<Module_Param*>();
    (yyval.module_param_list)->push_back((yyvsp[0].module_param_val));
  }
#line 3558 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 145:
#line 1280 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_list) = (yyvsp[-2].module_param_list);
    (yyval.module_param_list)->push_back((yyvsp[0].module_param_val));
  }
#line 3567 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 146:
#line 1288 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Assignment_List();
    (yyval.module_param_val)->add_elem((yyvsp[0].module_param_val));
  }
#line 3576 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 147:
#line 1293 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-2].module_param_val);
    (yyval.module_param_val)->add_elem((yyvsp[0].module_param_val));
  }
#line 3585 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 148:
#line 1301 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
    (yyval.module_param_val)->set_id(new Module_Param_FieldName((yyvsp[-2].str_val)));
  }
#line 3594 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 149:
#line 1309 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.str_val) = (yyvsp[0].str_val);
  }
#line 3602 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 150:
#line 1313 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.str_val) = (yyvsp[0].str_val);
  }
#line 3610 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 151:
#line 1320 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Value_List();
    (yyvsp[0].module_param_val)->set_id(new Module_Param_Index((yyval.module_param_val)->get_size(),false));
    (yyval.module_param_val)->add_elem((yyvsp[0].module_param_val));
  }
#line 3620 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 152:
#line 1326 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-2].module_param_val);
    (yyvsp[0].module_param_val)->set_id(new Module_Param_Index((yyval.module_param_val)->get_size(),false));
    (yyval.module_param_val)->add_elem((yyvsp[0].module_param_val));
  }
#line 3630 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 153:
#line 1335 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
  }
#line 3638 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 154:
#line 1339 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Permutation_Template();
    (yyval.module_param_val)->add_list_with_implicit_ids((yyvsp[-1].module_param_list));
    delete (yyvsp[-1].module_param_list);
  }
#line 3648 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 155:
#line 1348 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = new Module_Param_Indexed_List();
    (yyval.module_param_val)->add_elem((yyvsp[0].module_param_val));
  }
#line 3657 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 156:
#line 1353 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[-2].module_param_val);
    (yyval.module_param_val)->add_elem((yyvsp[0].module_param_val));
  }
#line 3666 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 157:
#line 1361 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.module_param_val) = (yyvsp[0].module_param_val);
    (yyval.module_param_val)->set_id(new Module_Param_Index((size_t)(yyvsp[-2].int_native),true));
  }
#line 3675 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 158:
#line 1369 "config_process.y" /* yacc.c:1646  */
    {
  (yyvsp[-1].module_param_val)->set_id(new Module_Param_CustomName(mcopystr("array index")));
  INTEGER tmp;
  tmp.set_param(*(yyvsp[-1].module_param_val));
  if (!tmp.get_val().is_native()) {
    config_process_error("bignum index."); // todo
  }
  if (tmp.get_val().is_negative()) {
    config_process_error("negative index."); // todo
  }
  (yyval.int_native) = tmp;
  delete (yyvsp[-1].module_param_val);
}
#line 3693 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 161:
#line 1393 "config_process.y" /* yacc.c:1646  */
    {
	  // Centralized duplication handling for `[LOGGING]'.
    if ((yyvsp[-1].logging_param_line).logparam.log_param_selection != LP_UNKNOWN && TTCN_Logger::add_parameter((yyvsp[-1].logging_param_line))) {
      switch ((yyvsp[-1].logging_param_line).logparam.log_param_selection) {
      case LP_FILEMASK:
        check_duplicate_option("LOGGING", "FileMask", file_mask_set);
        break;
      case LP_CONSOLEMASK:
        check_duplicate_option("LOGGING", "ConsoleMask", console_mask_set);
        break;
      case LP_LOGFILESIZE:
        check_duplicate_option("LOGGING", "LogFileSize", log_file_size_set);
        break;
      case LP_LOGFILENUMBER:
        check_duplicate_option("LOGGING", "LogFileNumber", log_file_number_set);
        break;
      case LP_DISKFULLACTION:
        check_duplicate_option("LOGGING", "DiskFullAction", log_disk_full_action_set);
        break;
      case LP_LOGFILE:
        check_duplicate_option("LOGGING", "LogFile", file_name_set);
        break;
      case LP_TIMESTAMPFORMAT:
        check_duplicate_option("LOGGING", "TimeStampFormat", timestamp_format_set);
        break;
      case LP_SOURCEINFOFORMAT:
        check_duplicate_option("LOGGING", "SourceInfoFormat", source_info_format_set);
        break;
      case LP_APPENDFILE:
        check_duplicate_option("LOGGING", "AppendFile", append_file_set);
        break;
      case LP_LOGEVENTTYPES:
        check_duplicate_option("LOGGING", "LogEventTypes", log_event_types_set);
        break;
      case LP_LOGENTITYNAME:
        check_duplicate_option("LOGGING", "LogEntityName", log_entity_name_set);
        break;
      case LP_MATCHINGHINTS:
        check_duplicate_option("LOGGING", "MatchingVerbosity", matching_verbosity_set);
        break;
      case LP_PLUGIN_SPECIFIC:
        // It would be an overkill to check for the infinite number of custom parameters...
        check_duplicate_option("LOGGING", "PluginSpecific", plugin_specific_set);
        break;
      default:
        break;
      }
    }
  }
#line 3747 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 162:
#line 1446 "config_process.y" /* yacc.c:1646  */
    {
		(yyval.logging_param_line).component.id_selector = COMPONENT_ID_ALL;
    (yyval.logging_param_line).component.id_name = NULL;
		(yyval.logging_param_line).plugin_id = NULL;
		(yyval.logging_param_line).logparam = (yyvsp[0].logging_params);
	}
#line 3758 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 163:
#line 1453 "config_process.y" /* yacc.c:1646  */
    {
		(yyval.logging_param_line).component = (yyvsp[-2].comp_id);
		(yyval.logging_param_line).plugin_id = NULL;
		(yyval.logging_param_line).logparam = (yyvsp[0].logging_params);
	}
#line 3768 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 164:
#line 1459 "config_process.y" /* yacc.c:1646  */
    {
		(yyval.logging_param_line).component = (yyvsp[-4].comp_id);
		(yyval.logging_param_line).plugin_id = (yyvsp[-2].str_val);
		(yyval.logging_param_line).logparam = (yyvsp[0].logging_params);
	}
#line 3778 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 165:
#line 1465 "config_process.y" /* yacc.c:1646  */
    {
	  check_duplicate_option("LOGGING", "LoggerPlugins", logger_plugins_set);
	  component_id_t comp;
	  comp.id_selector = COMPONENT_ID_ALL;
	  comp.id_name = NULL;
	  logging_plugin_t *plugin = (yyvsp[-1].logging_plugins);
	  while (plugin != NULL) {
	    // `identifier' and `filename' are reused.  Various checks and
	    // validations must be done in the logger itself (e.g. looking for
	    // duplicate options).
      TTCN_Logger::register_plugin(comp, plugin->identifier, plugin->filename);
      logging_plugin_t *tmp = plugin;
      plugin = tmp->next;
      Free(tmp);
	  }
	  (yyval.logging_param_line).logparam.log_param_selection = LP_UNKNOWN;
	}
#line 3800 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 166:
#line 1483 "config_process.y" /* yacc.c:1646  */
    {
    check_duplicate_option("LOGGING", "LoggerPlugins", logger_plugins_set);
    logging_plugin_t *plugin = (yyvsp[-1].logging_plugins);
    while (plugin != NULL) {
      TTCN_Logger::register_plugin((yyvsp[-6].comp_id), plugin->identifier, plugin->filename);
      logging_plugin_t *tmp = plugin;
      plugin = tmp->next;
      Free(tmp);
    }
    // Component names shall be duplicated in `register_plugin()'.
    if ((yyvsp[-6].comp_id).id_selector == COMPONENT_ID_NAME)
      Free((yyvsp[-6].comp_id).id_name);
    (yyval.logging_param_line).logparam.log_param_selection = LP_UNKNOWN;
	}
#line 3819 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 167:
#line 1501 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_plugins) = (yyvsp[0].logging_plugins);
  }
#line 3827 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 168:
#line 1505 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_plugins) = (yyvsp[0].logging_plugins);
    (yyval.logging_plugins)->next = (yyvsp[-2].logging_plugins);
  }
#line 3836 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 169:
#line 1513 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_plugins) = (logging_plugin_t *)Malloc(sizeof(logging_plugin_t));
    (yyval.logging_plugins)->identifier = (yyvsp[0].str_val);
    (yyval.logging_plugins)->filename = NULL;
    (yyval.logging_plugins)->next = NULL;
  }
#line 3847 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 170:
#line 1520 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_plugins) = (logging_plugin_t *)Malloc(sizeof(logging_plugin_t));
    (yyval.logging_plugins)->identifier = (yyvsp[-2].str_val);
    (yyval.logging_plugins)->filename = (yyvsp[0].str_val);
    (yyval.logging_plugins)->next = NULL;
  }
#line 3858 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 171:
#line 1529 "config_process.y" /* yacc.c:1646  */
    { (yyval.str_val) = mcopystr("*"); }
#line 3864 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 172:
#line 1530 "config_process.y" /* yacc.c:1646  */
    { (yyval.str_val) = (yyvsp[0].str_val); }
#line 3870 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 173:
#line 1535 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_FILEMASK;
    (yyval.logging_params).logoptions_val = (yyvsp[0].logoptions_val);
  }
#line 3879 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 174:
#line 1540 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_CONSOLEMASK;
    (yyval.logging_params).logoptions_val = (yyvsp[0].logoptions_val);
  }
#line 3888 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 175:
#line 1545 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_LOGFILESIZE;
    (yyval.logging_params).int_val = (int)(yyvsp[0].int_val)->get_val();
    delete (yyvsp[0].int_val);
  }
#line 3898 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 176:
#line 1551 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_EMERGENCY;
    (yyval.logging_params).int_val = (int)(yyvsp[0].int_val)->get_val();
    delete (yyvsp[0].int_val);
  }
#line 3908 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 177:
#line 1557 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_EMERGENCYBEHAVIOR;
    (yyval.logging_params).emergency_logging_behaviour_value = (yyvsp[0].emergency_logging_behaviour_value);
  }
#line 3917 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 178:
#line 1562 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_EMERGENCYMASK;
    (yyval.logging_params).logoptions_val = (yyvsp[0].logoptions_val);
  }
#line 3926 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 179:
#line 1567 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_EMERGENCYFORFAIL;
    (yyval.logging_params).bool_val = (yyvsp[0].bool_val);
  }
#line 3935 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 180:
#line 1572 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_LOGFILENUMBER;
    (yyval.logging_params).int_val = (int)(yyvsp[0].int_val)->get_val();
    delete (yyvsp[0].int_val);
  }
#line 3945 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 181:
#line 1578 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_DISKFULLACTION;
    (yyval.logging_params).disk_full_action_value = (yyvsp[0].disk_full_action_value);
  }
#line 3954 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 182:
#line 1583 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_LOGFILE;
    (yyval.logging_params).str_val = (yyvsp[0].str_val);
  }
#line 3963 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 183:
#line 1588 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_TIMESTAMPFORMAT;
    (yyval.logging_params).timestamp_value = (yyvsp[0].timestamp_value);
  }
#line 3972 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 184:
#line 1593 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_UNKNOWN;
  }
#line 3980 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 185:
#line 1597 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_SOURCEINFOFORMAT;
    (yyval.logging_params).source_info_value = (yyvsp[0].source_info_value);
  }
#line 3989 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 186:
#line 1602 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_APPENDFILE;
    (yyval.logging_params).bool_val = (yyvsp[0].bool_val);
  }
#line 3998 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 187:
#line 1607 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_LOGEVENTTYPES;
    (yyval.logging_params).log_event_types_value = (yyvsp[0].log_event_types_value);
  }
#line 4007 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 188:
#line 1612 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_LOGENTITYNAME;
    (yyval.logging_params).bool_val = (yyvsp[0].bool_val);
  }
#line 4016 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 189:
#line 1617 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_MATCHINGHINTS;
    (yyval.logging_params).matching_verbosity_value = (yyvsp[0].matching_verbosity_value);
  }
#line 4025 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 190:
#line 1622 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logging_params).log_param_selection = LP_PLUGIN_SPECIFIC;
    (yyval.logging_params).param_name = (yyvsp[-2].str_val);
    (yyval.logging_params).str_val = (yyvsp[0].str_val);
  }
#line 4035 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 191:
#line 1630 "config_process.y" /* yacc.c:1646  */
    { (yyval.matching_verbosity_value) = TTCN_Logger::VERBOSITY_COMPACT; }
#line 4041 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 192:
#line 1631 "config_process.y" /* yacc.c:1646  */
    { (yyval.matching_verbosity_value) = TTCN_Logger::VERBOSITY_FULL; }
#line 4047 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 193:
#line 1635 "config_process.y" /* yacc.c:1646  */
    { (yyval.disk_full_action_value).type = TTCN_Logger::DISKFULL_ERROR; }
#line 4053 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 194:
#line 1636 "config_process.y" /* yacc.c:1646  */
    { (yyval.disk_full_action_value).type = TTCN_Logger::DISKFULL_STOP; }
#line 4059 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 195:
#line 1638 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.disk_full_action_value).type = TTCN_Logger::DISKFULL_RETRY;
    (yyval.disk_full_action_value).retry_interval = 30; /* default retry interval */
}
#line 4068 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 196:
#line 1643 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.disk_full_action_value).type = TTCN_Logger::DISKFULL_RETRY;
    (yyval.disk_full_action_value).retry_interval = (size_t)(yyvsp[-1].int_val)->get_val();
    delete (yyvsp[-1].int_val);
}
#line 4078 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 197:
#line 1648 "config_process.y" /* yacc.c:1646  */
    { (yyval.disk_full_action_value).type = TTCN_Logger::DISKFULL_DELETE; }
#line 4084 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 198:
#line 1652 "config_process.y" /* yacc.c:1646  */
    { (yyval.str_val) = (yyvsp[0].str_val); }
#line 4090 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 199:
#line 1657 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logoptions_val).clear();
    (yyval.logoptions_val).add_sev((yyvsp[0].logseverity_val));
}
#line 4099 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 200:
#line 1662 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.logoptions_val).clear();
    switch((yyvsp[0].logseverity_val))
    {
    case TTCN_Logger::ACTION_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::ACTION_UNQUALIFIED);
	break;
    case TTCN_Logger::DEFAULTOP_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEFAULTOP_ACTIVATE);
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEFAULTOP_DEACTIVATE);
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEFAULTOP_EXIT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEFAULTOP_UNQUALIFIED);
	break;
    case TTCN_Logger::ERROR_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::ERROR_UNQUALIFIED);
	break;
    case TTCN_Logger::EXECUTOR_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::EXECUTOR_RUNTIME);
	(yyval.logoptions_val).add_sev(TTCN_Logger::EXECUTOR_CONFIGDATA);
	(yyval.logoptions_val).add_sev(TTCN_Logger::EXECUTOR_EXTCOMMAND);
	(yyval.logoptions_val).add_sev(TTCN_Logger::EXECUTOR_COMPONENT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::EXECUTOR_LOGOPTIONS);
	(yyval.logoptions_val).add_sev(TTCN_Logger::EXECUTOR_UNQUALIFIED);
	break;
    case TTCN_Logger::FUNCTION_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::FUNCTION_RND);
	(yyval.logoptions_val).add_sev(TTCN_Logger::FUNCTION_UNQUALIFIED);
	break;
    case TTCN_Logger::PARALLEL_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::PARALLEL_PTC);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PARALLEL_PORTCONN);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PARALLEL_PORTMAP);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PARALLEL_UNQUALIFIED);
	break;
    case TTCN_Logger::PORTEVENT_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_PQUEUE);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_MQUEUE);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_STATE);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_PMIN);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_PMOUT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_PCIN);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_PCOUT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_MMRECV);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_MMSEND);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_MCRECV);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_MCSEND);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_DUALRECV);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_DUALSEND);
	(yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_UNQUALIFIED);
  (yyval.logoptions_val).add_sev(TTCN_Logger::PORTEVENT_SETSTATE);
	break;
    case TTCN_Logger::TESTCASE_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::TESTCASE_START);
	(yyval.logoptions_val).add_sev(TTCN_Logger::TESTCASE_FINISH);
	(yyval.logoptions_val).add_sev(TTCN_Logger::TESTCASE_UNQUALIFIED);
	break;
    case TTCN_Logger::TIMEROP_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::TIMEROP_READ);
	(yyval.logoptions_val).add_sev(TTCN_Logger::TIMEROP_START);
	(yyval.logoptions_val).add_sev(TTCN_Logger::TIMEROP_GUARD);
	(yyval.logoptions_val).add_sev(TTCN_Logger::TIMEROP_STOP);
	(yyval.logoptions_val).add_sev(TTCN_Logger::TIMEROP_TIMEOUT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::TIMEROP_UNQUALIFIED);
	break;
    case TTCN_Logger::USER_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::USER_UNQUALIFIED);
	break;
    case TTCN_Logger::STATISTICS_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::STATISTICS_VERDICT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::STATISTICS_UNQUALIFIED);
	break;
    case TTCN_Logger::VERDICTOP_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::VERDICTOP_GETVERDICT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::VERDICTOP_SETVERDICT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::VERDICTOP_FINAL);
	(yyval.logoptions_val).add_sev(TTCN_Logger::VERDICTOP_UNQUALIFIED);
	break;
    case TTCN_Logger::WARNING_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::WARNING_UNQUALIFIED);
	break;
    case TTCN_Logger::MATCHING_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_DONE);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_TIMEOUT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_PCSUCCESS);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_PCUNSUCC);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_PMSUCCESS);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_PMUNSUCC);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_MCSUCCESS);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_MCUNSUCC);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_MMSUCCESS);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_MMUNSUCC);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_PROBLEM);
	(yyval.logoptions_val).add_sev(TTCN_Logger::MATCHING_UNQUALIFIED);
	break;
    case TTCN_Logger::DEBUG_UNQUALIFIED:
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEBUG_ENCDEC);
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEBUG_TESTPORT);
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEBUG_USER);
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEBUG_FRAMEWORK);
	(yyval.logoptions_val).add_sev(TTCN_Logger::DEBUG_UNQUALIFIED);
	break;
    case TTCN_Logger::LOG_ALL_IMPORTANT:
	(yyval.logoptions_val) = Logging_Bits::log_all;
	break;
    default:
	/*  The lexer sent something the parser doesn't understand!
	    Parser needs to be updated.
	*/
        TTCN_Logger::log_str(TTCN_Logger::ERROR_UNQUALIFIED,
          "Internal error: unknown logbit from lexer.");
	break;
    } // switch
}
#line 4217 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 201:
#line 1779 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.logoptions_val) = (yyvsp[0].logoptions_val);
}
#line 4225 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 202:
#line 1783 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.logoptions_val) = (yyvsp[-2].logoptions_val);
	(yyval.logoptions_val).merge((yyvsp[0].logoptions_val));
}
#line 4234 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 203:
#line 1790 "config_process.y" /* yacc.c:1646  */
    { (yyval.source_info_value) = (yyvsp[0].source_info_value); }
#line 4240 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 204:
#line 1792 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.source_info_value) = (yyvsp[0].bool_val) ? TTCN_Logger::SINFO_SINGLE : TTCN_Logger::SINFO_NONE;
}
#line 4248 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 205:
#line 1798 "config_process.y" /* yacc.c:1646  */
    { (yyval.bool_val) = (yyvsp[0].bool_val); }
#line 4254 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 206:
#line 1799 "config_process.y" /* yacc.c:1646  */
    { (yyval.bool_val) = (yyvsp[0].bool_val); }
#line 4260 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 207:
#line 1803 "config_process.y" /* yacc.c:1646  */
    { (yyval.log_event_types_value) = (yyvsp[0].bool_val) ? TTCN_Logger::LOGEVENTTYPES_YES :
			TTCN_Logger::LOGEVENTTYPES_NO; }
#line 4267 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 208:
#line 1805 "config_process.y" /* yacc.c:1646  */
    { (yyval.log_event_types_value) = TTCN_Logger::LOGEVENTTYPES_SUBCATEGORIES; }
#line 4273 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 209:
#line 1806 "config_process.y" /* yacc.c:1646  */
    { (yyval.log_event_types_value) = TTCN_Logger::LOGEVENTTYPES_SUBCATEGORIES; }
#line 4279 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 223:
#line 1834 "config_process.y" /* yacc.c:1646  */
    {
    ttcn3_prof.set_disable_profiler((yyvsp[0].bool_val));
  }
#line 4287 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 224:
#line 1840 "config_process.y" /* yacc.c:1646  */
    {
    ttcn3_prof.set_disable_coverage((yyvsp[0].bool_val));
  }
#line 4295 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 225:
#line 1846 "config_process.y" /* yacc.c:1646  */
    {
    ttcn3_prof.set_database_filename((yyvsp[0].str_val));
  }
#line 4303 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 226:
#line 1852 "config_process.y" /* yacc.c:1646  */
    {
    ttcn3_prof.set_aggregate_data((yyvsp[0].bool_val));
  }
#line 4311 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 227:
#line 1858 "config_process.y" /* yacc.c:1646  */
    {
    ttcn3_prof.set_stats_filename((yyvsp[0].str_val));
  }
#line 4319 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 228:
#line 1864 "config_process.y" /* yacc.c:1646  */
    {
    ttcn3_prof.set_disable_stats((yyvsp[0].bool_val));
  }
#line 4327 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 229:
#line 1870 "config_process.y" /* yacc.c:1646  */
    {
    ttcn3_prof.reset_stats_flags();
    ttcn3_prof.add_stats_flags((yyvsp[0].uint_val));
  }
#line 4336 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 230:
#line 1874 "config_process.y" /* yacc.c:1646  */
    {
    ttcn3_prof.add_stats_flags((yyvsp[0].uint_val));
  }
#line 4344 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 231:
#line 1880 "config_process.y" /* yacc.c:1646  */
    { (yyval.uint_val) = (yyvsp[0].uint_val); }
#line 4350 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 232:
#line 1881 "config_process.y" /* yacc.c:1646  */
    { (yyval.uint_val) = (yyvsp[-2].uint_val) | (yyvsp[0].uint_val); }
#line 4356 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 233:
#line 1882 "config_process.y" /* yacc.c:1646  */
    { (yyval.uint_val) = (yyvsp[-2].uint_val) | (yyvsp[0].uint_val); }
#line 4362 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 234:
#line 1886 "config_process.y" /* yacc.c:1646  */
    {
    if ((yyvsp[0].bool_val)) {
      ttcn3_prof.start();
    }
    else {
      ttcn3_prof.stop();
    }
  }
#line 4375 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 235:
#line 1897 "config_process.y" /* yacc.c:1646  */
    {
    TTCN3_Stack_Depth::set_net_line_times((yyvsp[0].bool_val));
  }
#line 4383 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 236:
#line 1903 "config_process.y" /* yacc.c:1646  */
    {
    TTCN3_Stack_Depth::set_net_func_times((yyvsp[0].bool_val));
  }
#line 4391 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 240:
#line 1923 "config_process.y" /* yacc.c:1646  */
    {
	PORT::add_parameter((yyvsp[-6].comp_id), (yyvsp[-4].str_val), (yyvsp[-2].str_val), (yyvsp[0].str_val));
	if ((yyvsp[-6].comp_id).id_selector == COMPONENT_ID_NAME) Free((yyvsp[-6].comp_id).id_name);
	Free((yyvsp[-4].str_val));
	Free((yyvsp[-2].str_val));
	Free((yyvsp[0].str_val));
}
#line 4403 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 241:
#line 1934 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.comp_id).id_selector = COMPONENT_ID_NAME;
	(yyval.comp_id).id_name = (yyvsp[0].str_val);
}
#line 4412 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 242:
#line 1939 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.comp_id).id_selector = COMPONENT_ID_NAME;
	(yyval.comp_id).id_name = (yyvsp[0].charstring_val).chars_ptr;
}
#line 4421 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 243:
#line 1944 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.comp_id).id_selector = COMPONENT_ID_COMPREF;
	(yyval.comp_id).id_compref = (component)(yyvsp[0].int_val)->get_val();
	delete (yyvsp[0].int_val);
}
#line 4431 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 244:
#line 1950 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.comp_id).id_selector = COMPONENT_ID_COMPREF;
	(yyval.comp_id).id_compref = MTC_COMPREF;
}
#line 4440 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 245:
#line 1955 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.comp_id).id_selector = COMPONENT_ID_ALL;
	(yyval.comp_id).id_name = NULL;
}
#line 4449 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 246:
#line 1960 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.comp_id).id_selector = COMPONENT_ID_SYSTEM;
	(yyval.comp_id).id_name = NULL;
}
#line 4458 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 247:
#line 1967 "config_process.y" /* yacc.c:1646  */
    { (yyval.str_val) = (yyvsp[0].str_val); }
#line 4464 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 248:
#line 1969 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.str_val) = mputstr((yyvsp[-1].str_val), (yyvsp[0].str_val));
	Free((yyvsp[0].str_val));
}
#line 4473 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 249:
#line 1973 "config_process.y" /* yacc.c:1646  */
    { (yyval.str_val) = NULL; }
#line 4479 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 250:
#line 1978 "config_process.y" /* yacc.c:1646  */
    {
	char *s = (yyvsp[-1].int_val)->as_string();
	(yyval.str_val) = memptystr();
	(yyval.str_val) = mputc  ((yyval.str_val), '[');
	(yyval.str_val) = mputstr((yyval.str_val), s);
	(yyval.str_val) = mputc  ((yyval.str_val), ']');
	Free(s);
	delete (yyvsp[-1].int_val);
}
#line 4493 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 251:
#line 1988 "config_process.y" /* yacc.c:1646  */
    {
	char *s = (yyvsp[-1].int_val)->as_string();
	(yyval.str_val) = mputc  ((yyvsp[-3].str_val), '[');
	(yyval.str_val) = mputstr((yyval.str_val), s);
	(yyval.str_val) = mputc  ((yyval.str_val), ']');
	Free(s);
	delete (yyvsp[-1].int_val);
}
#line 4506 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 252:
#line 1999 "config_process.y" /* yacc.c:1646  */
    { (yyval.str_val) = (yyvsp[0].str_val); }
#line 4512 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 253:
#line 2003 "config_process.y" /* yacc.c:1646  */
    { (yyval.str_val) = (yyvsp[0].str_val); }
#line 4518 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 254:
#line 2010 "config_process.y" /* yacc.c:1646  */
    {
    if (!TTCN_Runtime::is_single()) config_process_error("Internal error: "
	"the Main Controller must not send section [EXECUTE] of the "
	"configuration file.");
}
#line 4528 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 256:
#line 2020 "config_process.y" /* yacc.c:1646  */
    {
	if (TTCN_Runtime::is_single()) {
		execute_list = (execute_list_item *)Realloc(
			execute_list, (execute_list_len + 1) *
			sizeof(*execute_list));
		execute_list[execute_list_len++] = (yyvsp[-1].execute_item_val);
	} else {
		Free((yyvsp[-1].execute_item_val).module_name);
		Free((yyvsp[-1].execute_item_val).testcase_name);
	}
}
#line 4544 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 257:
#line 2035 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.execute_item_val).module_name = (yyvsp[0].str_val);
	(yyval.execute_item_val).testcase_name = NULL;
}
#line 4553 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 258:
#line 2040 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.execute_item_val).module_name = (yyvsp[-2].str_val);
	(yyval.execute_item_val).testcase_name = NULL;
}
#line 4562 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 259:
#line 2045 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.execute_item_val).module_name = (yyvsp[-2].str_val);
	(yyval.execute_item_val).testcase_name = (yyvsp[0].str_val);
}
#line 4571 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 260:
#line 2050 "config_process.y" /* yacc.c:1646  */
    {
	(yyval.execute_item_val).module_name = (yyvsp[-2].str_val);
	(yyval.execute_item_val).testcase_name = mcopystr("*");
}
#line 4580 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 264:
#line 2069 "config_process.y" /* yacc.c:1646  */
    {
    check_duplicate_option("EXTERNAL_COMMANDS", "BeginControlPart",
	begin_controlpart_command_set);

    TTCN_Runtime::set_begin_controlpart_command((yyvsp[0].str_val));

    Free((yyvsp[0].str_val));
}
#line 4593 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 265:
#line 2078 "config_process.y" /* yacc.c:1646  */
    {
    check_duplicate_option("EXTERNAL_COMMANDS", "EndControlPart",
	end_controlpart_command_set);

    TTCN_Runtime::set_end_controlpart_command((yyvsp[0].str_val));

    Free((yyvsp[0].str_val));
}
#line 4606 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 266:
#line 2087 "config_process.y" /* yacc.c:1646  */
    {
    check_duplicate_option("EXTERNAL_COMMANDS", "BeginTestCase",
	begin_testcase_command_set);

    TTCN_Runtime::set_begin_testcase_command((yyvsp[0].str_val));

    Free((yyvsp[0].str_val));
}
#line 4619 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 267:
#line 2096 "config_process.y" /* yacc.c:1646  */
    {
    check_duplicate_option("EXTERNAL_COMMANDS", "EndTestCase",
	end_testcase_command_set);

    TTCN_Runtime::set_end_testcase_command((yyvsp[0].str_val));

    Free((yyvsp[0].str_val));
}
#line 4632 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 268:
#line 2107 "config_process.y" /* yacc.c:1646  */
    { (yyval.str_val) = (yyvsp[0].str_val); }
#line 4638 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 269:
#line 2114 "config_process.y" /* yacc.c:1646  */
    {
    check_ignored_section("GROUPS");
}
#line 4646 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 273:
#line 2129 "config_process.y" /* yacc.c:1646  */
    { Free((yyvsp[0].str_val)); }
#line 4652 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 279:
#line 2144 "config_process.y" /* yacc.c:1646  */
    { Free((yyvsp[0].str_val)); }
#line 4658 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 280:
#line 2150 "config_process.y" /* yacc.c:1646  */
    {
    check_ignored_section("COMPONENTS");
}
#line 4666 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 284:
#line 2165 "config_process.y" /* yacc.c:1646  */
    { Free((yyvsp[0].str_val)); }
#line 4672 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 286:
#line 2170 "config_process.y" /* yacc.c:1646  */
    { Free((yyvsp[0].str_val)); }
#line 4678 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 288:
#line 2177 "config_process.y" /* yacc.c:1646  */
    {
    check_ignored_section("MAIN_CONTROLLER");
}
#line 4686 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 291:
#line 2188 "config_process.y" /* yacc.c:1646  */
    { }
#line 4692 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 292:
#line 2189 "config_process.y" /* yacc.c:1646  */
    { delete (yyvsp[0].int_val); }
#line 4698 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 293:
#line 2190 "config_process.y" /* yacc.c:1646  */
    { }
#line 4704 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 294:
#line 2191 "config_process.y" /* yacc.c:1646  */
    { delete (yyvsp[0].int_val); }
#line 4710 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 295:
#line 2192 "config_process.y" /* yacc.c:1646  */
    {}
#line 4716 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 296:
#line 2193 "config_process.y" /* yacc.c:1646  */
    {}
#line 4722 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 297:
#line 2194 "config_process.y" /* yacc.c:1646  */
    {}
#line 4728 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 298:
#line 2198 "config_process.y" /* yacc.c:1646  */
    { }
#line 4734 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 299:
#line 2199 "config_process.y" /* yacc.c:1646  */
    { delete (yyvsp[0].int_val); }
#line 4740 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 300:
#line 2205 "config_process.y" /* yacc.c:1646  */
    {
    if(!TTCN_Runtime::is_single())
      config_process_error
        ("Internal error: the Main Controller must not send section [INCLUDE]"
         " of the configuration file.");
  }
#line 4751 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 303:
#line 2219 "config_process.y" /* yacc.c:1646  */
    { Free((yyvsp[0].charstring_val).chars_ptr); }
#line 4757 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 304:
#line 2225 "config_process.y" /* yacc.c:1646  */
    {
    if(!TTCN_Runtime::is_single())
      config_process_error
        ("Internal error: the Main Controller must not send section [DEFINE]"
         " of the configuration file.");
  }
#line 4768 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 305:
#line 2237 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.param_optype_val) = Module_Param::OT_ASSIGN;
  }
#line 4776 "config_process.tab.cc" /* yacc.c:1646  */
    break;

  case 306:
#line 2242 "config_process.y" /* yacc.c:1646  */
    {
    (yyval.param_optype_val) = Module_Param::OT_CONCAT;
  }
#line 4784 "config_process.tab.cc" /* yacc.c:1646  */
    break;


#line 4788 "config_process.tab.cc" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 2252 "config_process.y" /* yacc.c:1906  */


static void reset_configuration_options()
{
    /* Section [MODULE_PARAMETERS */
    /** \todo reset module parameters to their default values */
    /* Section [LOGGING] */
    TTCN_Logger::close_file();
    TTCN_Logger::reset_configuration();
    file_name_set = FALSE;
    file_mask_set = TRUE;
    console_mask_set = TRUE;
    timestamp_format_set = FALSE;
    source_info_format_set = FALSE;
    append_file_set = FALSE;
    log_event_types_set = FALSE;
    log_entity_name_set = FALSE;
    /* Section [TESTPORT_PARAMETERS] */
    PORT::clear_parameters();
    /* Section [EXTERNAL_COMMANDS] */

    TTCN_Runtime::clear_external_commands();

    begin_controlpart_command_set = FALSE;
    end_controlpart_command_set = FALSE;
    begin_testcase_command_set = FALSE;
    end_testcase_command_set = FALSE;
}

Module_Param* process_config_string2ttcn(const char* mp_str, boolean is_component)
{
  if (parsed_module_param!=NULL || parsing_error_messages!=NULL) TTCN_error("Internal error: previously parsed ttcn string was not cleared.");
  // add the hidden keyword
  std::string mp_string = (is_component) ? std::string("$#&&&(#TTCNSTRINGPARSING_COMPONENT$#&&^#% ") + mp_str
    : std::string("$#&&&(#TTCNSTRINGPARSING$#&&^#% ") + mp_str;
  struct yy_buffer_state *flex_buffer = config_process__scan_bytes(mp_string.c_str(), (int)mp_string.size());
  if (flex_buffer == NULL) TTCN_error("Internal error: flex buffer creation failed.");
  reset_config_process_lex(NULL);
  error_flag = FALSE;
  try {
    Ttcn_String_Parsing ttcn_string_parsing;
    if (config_process_parse()) error_flag = TRUE;
  } catch (const TC_Error& TC_error) {
    if (parsed_module_param!=NULL) { delete parsed_module_param; parsed_module_param = NULL; }
    error_flag = TRUE;
  }
  config_process_close();
  config_process_lex_destroy();

  if (error_flag || parsing_error_messages!=NULL) {
    delete parsed_module_param;
    parsed_module_param = NULL;
    char* pem = parsing_error_messages!=NULL ? parsing_error_messages : mcopystr("Unknown parsing error");
    parsing_error_messages = NULL;
    TTCN_error_begin("%s", pem);
    Free(pem);
    TTCN_error_end();
    return NULL;
  } else {
    if (parsed_module_param==NULL) TTCN_error("Internal error: could not parse ttcn string.");
    Module_Param* ret_val = parsed_module_param;
    parsed_module_param = NULL;
    return ret_val;
  }
}

Module_Param* process_config_debugger_value(const char* mp_str)
{
  if (parsed_module_param != NULL || parsing_error_messages != NULL) {
    ttcn3_debugger.print(DRET_NOTIFICATION,
      "Internal error: previously parsed TTCN string was not cleared.");
    return NULL;
  }
  // add the hidden keyword
  std::string mp_string = std::string("$#&&&(#TTCNSTRINGPARSING$#&&^#% ") + mp_str;
  struct yy_buffer_state *flex_buffer = config_process__scan_bytes(mp_string.c_str(), (int)mp_string.size());
  if (flex_buffer == NULL) {
    ttcn3_debugger.print(DRET_NOTIFICATION, "Internal error: flex buffer creation failed.");
    return NULL;
  }
  reset_config_process_lex(NULL);
  error_flag = FALSE;
  try {
    Debugger_Value_Parsing debugger_value_parsing;
    if (config_process_parse()) {
      error_flag = TRUE;
    }
  }
  catch (const TC_Error& TC_error) {
    if (parsed_module_param != NULL) {
      delete parsed_module_param;
      parsed_module_param = NULL;
    }
    error_flag = TRUE;
  }
  config_process_close();
  config_process_lex_destroy();

  if (error_flag || parsing_error_messages != NULL) {
    delete parsed_module_param;
    parsed_module_param = NULL;
    char* pem = parsing_error_messages != NULL ? parsing_error_messages :
      mcopystr("Unknown parsing error");
    parsing_error_messages = NULL;
    ttcn3_debugger.print(DRET_NOTIFICATION, "%s", pem);
    Free(pem);
    return NULL;
  }
  else {
    if (parsed_module_param == NULL) {
      ttcn3_debugger.print(DRET_NOTIFICATION, "Internal error: could not parse TTCN string.");
      return NULL;
    }
    Module_Param* ret_val = parsed_module_param;
    parsed_module_param = NULL;
    return ret_val;
  }
}

boolean process_config_string(const char *config_string, int string_len)
{
  error_flag = FALSE;

  struct yy_buffer_state *flex_buffer =
    config_process__scan_bytes(config_string, string_len);
  if (flex_buffer == NULL) {
    TTCN_Logger::log_str(TTCN_Logger::ERROR_UNQUALIFIED,
      "Internal error: flex buffer creation failed.");
    return FALSE;
  }

  try {
    reset_configuration_options();
    reset_config_process_lex(NULL); 

    if (config_process_parse()) error_flag = TRUE;

  } catch (const TC_Error& TC_error) {
    error_flag = TRUE;
  }

  config_process_close();
  config_process_lex_destroy();

  return !error_flag;
}


boolean process_config_file(const char *file_name)
{
  error_flag = FALSE;
  string_chain_t *filenames=NULL;

  reset_configuration_options();

  if(preproc_parse_file(file_name, &filenames, &config_defines))
    error_flag=TRUE;

  while(filenames) {
    char *fn=string_chain_cut(&filenames);
    reset_config_process_lex(fn);
    /* The lexer can modify config_process_in
     * when it's input buffer is changed */
    config_process_in = fopen(fn, "r");
    FILE* tmp_cfg = config_process_in;
    if (config_process_in != NULL) {
      try {
	if(config_process_parse()) error_flag=TRUE;
      } catch (const TC_Error& TC_error) {
	error_flag=TRUE;
      }
      fclose(tmp_cfg);
      config_process_close();
      config_process_lex_destroy();
    } else {
      TTCN_Logger::begin_event(TTCN_Logger::ERROR_UNQUALIFIED);
      TTCN_Logger::log_event("Cannot open configuration file: %s", fn);
      TTCN_Logger::OS_error();
      TTCN_Logger::end_event();
      error_flag=TRUE;
    }
    /* During parsing flex or libc may use some system calls (e.g. ioctl)
     * that fail with an error status. Such error codes shall be ignored in
     * future error messages. */
    errno = 0;

    Free(fn);
  }

  string_map_free(config_defines);
  config_defines = NULL;

  return !error_flag;
}

void config_process_error_f(const char *error_str, ...)
{
  if (Ttcn_String_Parsing::happening() || Debugger_Value_Parsing::happening()) {
    va_list p_var;
    va_start(p_var, error_str);
    char* error_msg_str = mprintf_va_list(error_str, p_var);
    va_end(p_var);
    if (parsing_error_messages!=NULL) parsing_error_messages = mputc(parsing_error_messages, '\n');
    if (Debugger_Value_Parsing::happening()) {
      parsing_error_messages = mputprintf(parsing_error_messages,
        "Parse error at or before token `%s': %s", config_process_text, error_msg_str);
    }
    else { // Ttcn_String_Parsing::happening()
      parsing_error_messages = mputprintf(parsing_error_messages,
        "Parse error in line %d, at or before token `%s': %s", config_process_get_current_line(), config_process_text, error_msg_str);
    }
    Free(error_msg_str);
    error_flag = TRUE;
    return;
  }
  TTCN_Logger::begin_event(TTCN_Logger::ERROR_UNQUALIFIED);
  if (!get_cfg_process_current_file().empty()) {
    TTCN_Logger::log_event("Parse error in configuration file `%s': in line %d, "
                          "at or before token `%s': ",
      get_cfg_process_current_file().c_str(), config_process_get_current_line(),
      config_process_text
      );
  } else {
    TTCN_Logger::log_event("Parse error while reading configuration "
      "information: in line %d, at or before token `%s': ",
      config_process_get_current_line(), config_process_text);
  }
  va_list pvar;
  va_start(pvar, error_str);
  TTCN_Logger::log_event_va_list(error_str, pvar);
  va_end(pvar);
  TTCN_Logger::end_event();
  error_flag = TRUE;
}

void config_process_error(const char *error_str)
{
  config_process_error_f("%s", error_str);
}

void config_preproc_error(const char *error_str, ...)
{
    TTCN_Logger::begin_event(TTCN_Logger::ERROR_UNQUALIFIED);
    TTCN_Logger::log_event("Parse error while pre-processing configuration"
                           " file `%s': in line %d: ",
                           get_cfg_preproc_current_file().c_str(),
                           config_preproc_yylineno);
    va_list pvar;
    va_start(pvar, error_str);
    TTCN_Logger::log_event_va_list(error_str, pvar);
    va_end(pvar);
    TTCN_Logger::end_event();
    error_flag = TRUE;
}

void path_error(const char *fmt, ...)
{
  va_list parameters;
  fprintf(stderr, "File error: ");
  va_start(parameters, fmt);
  vfprintf(stderr, fmt, parameters);
  va_end(parameters);
  fprintf(stderr, "\n");
}

static void check_duplicate_option(const char *section_name,
    const char *option_name, boolean& option_flag)
{
  if (option_flag) {
    TTCN_warning("Option `%s' was given more than once in section [%s] of the "
      "configuration file.", option_name, section_name);
  } else option_flag = TRUE;
}

static void check_ignored_section(const char *section_name)
{
  if (TTCN_Runtime::is_single()) TTCN_warning("Section [%s] of "
      "configuration file is ignored in single mode.", section_name);
  else config_process_error_f("Internal error: the Main Controller must not "
      "send section [%s] of the configuration file.", section_name);
}

static void set_param(Module_Param& param)
{
  try {
    Module_List::set_param(param);
  }
  catch (const TC_Error& TC_error) {
    error_flag = TRUE;
  }
}

unsigned char char_to_hexdigit_(char c)
{
  if (c >= '0' && c <= '9') return c - '0';
  else if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  else if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  else {
    config_process_error_f("char_to_hexdigit_(): invalid argument: %c", c);
    return 0; // to avoid warning
  }
}
